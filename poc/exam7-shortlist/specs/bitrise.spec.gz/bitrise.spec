{
  "schemes": [
    "https"
  ],
  "swagger": "2.0",
  "info": {
    "description": "Official REST API for Bitrise.io",
    "title": "Bitrise API",
    "contact": {
      "name": "Bitrise Support",
      "url": "https://www.bitrise.io/contact",
      "email": "letsconnect@bitrise.io"
    },
    "license": {
      "name": "MIT"
    },
    "version": "0.1"
  },
  "host": "api.bitrise.io",
  "basePath": "/v0.1",
  "paths": {
    "/addons": {
      "get": {
        "description": "List all the available Bitrise addons",
        "produces": [
          "application/json"
        ],
        "tags": [
          "addons"
        ],
        "summary": "Get list of available Bitrise addons",
        "operationId": "addons-list",
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AddonsListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/addons/{addon-id}": {
      "get": {
        "description": "Show details of a specific Bitrise addon",
        "produces": [
          "application/json"
        ],
        "tags": [
          "addons"
        ],
        "summary": "Get a specific Bitrise addon",
        "operationId": "addons-show",
        "parameters": [
          {
            "type": "string",
            "description": "Addon ID",
            "name": "addon-id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AddonsShowResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all the apps available for the authenticated account, including those that are owned by other users or Organizations.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Get list of the apps",
        "operationId": "app-list",
        "parameters": [
          {
            "enum": [
              "last_build_at",
              "created_at"
            ],
            "type": "string",
            "description": "Order of the applications: sort them based on when they were created or the time of their last build",
            "name": "sort_by",
            "in": "query"
          },
          {
            "type": "string",
            "description": "Slug of the first app in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of elements per page (default: 50)",
            "name": "limit",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The title of the app",
            "name": "title",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The project type of the app (eg. 'ios', 'android')",
            "name": "project_type",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/register": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Add a new app to Bitrise. This is the first step of the app registration process. To successfully set it up, you need to provide the required app parameters: the repository URL and the isPublic field. Read more about the app creation process in our [detailed guide](https://devcenter.bitrise.io/api/adding-and-managing-apps/#adding-a-new-app).",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "app-setup"
        ],
        "summary": "Add a new app",
        "operationId": "app-create",
        "parameters": [
          {
            "description": "App parameters",
            "name": "app",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.AppUploadParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Get the details of a specific app by providing the app slug. You can get the app slug by calling the [/apps](https://api-docs.bitrise.io/#/application/app-list) endpoint or by opening the app on bitrise.io and copying the slug from the URL.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Get a specific app",
        "operationId": "app-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppShowResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Deletes an app by slug. Use with care, make sure you really want to delete the app. This action cannot be undone.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Deletes an app",
        "operationId": "app-delete",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppDeleteRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Updates an app by slug. Only updates the fields specified in the body.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Updates an app",
        "operationId": "app-update",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "App update params. All fields are optional, omit the fields you don't wish to update.",
            "name": "app",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.AppUpdateParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppUpdateRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/addons": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List all the provisioned addons for the authorized apps",
        "produces": [
          "application/json"
        ],
        "tags": [
          "addons"
        ],
        "summary": "Get list of the addons for apps",
        "operationId": "addon-list-by-app",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppAddOnsListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/android-keystore-files": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List all the android keystore files that have been uploaded to a specific app.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "android-keystore-file"
        ],
        "summary": "Get a list of the android keystore files",
        "operationId": "android-keystore-file-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Slug of the first android keystore file in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of build certificates per page is 50.",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AndroidKeystoreFileListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Add a new Android keystore file to an app. `keystore_file_name` is required if there is already an existing keystore file for the app. It will determine the environment variable key to be used to refer to the keystore file in builds. E.g. `BITRISE_ANDROID_KEYSTORE_\u003ckeystore_file_name\u003e_URL`. The `keystore_file_name` can only contain letters, numbers, and underscores.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "android-keystore-file"
        ],
        "summary": "Create an Android keystore file",
        "operationId": "android-keystore-file-create",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Android keystore file parameters",
            "name": "android-keystore-file",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.AndroidKeystoreFileUploadParams"
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "$ref": "#/definitions/v0.AndroidKeystoreFileUploadResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/android-keystore-files/{android-keystore-file-slug}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Retrieve data of a specific Android Keystore file to check its attributes.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "android-keystore-file"
        ],
        "summary": "Get a specific Android Keystore file",
        "operationId": "android-keystore-file-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Android Keystore file slug",
            "name": "android-keystore-file-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AndroidKeystoreFileDownloadResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Delete an app's android keystore file. You can fetch an app's android keystore file slug if you first list all the uploaded files with the [GET /apps/{app-slug}/android-keystore-files](https://api-docs.bitrise.io/#/android-keystore-file/android-keystore-file-list) endpoint. Read more in our [Deleting a file](https://devcenter.bitrise.io/api/managing-android-keystore-files.html) guide.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "android-keystore-file"
        ],
        "summary": "Delete an android keystore file",
        "operationId": "android-keystore-file-delete",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Android keystore file slug",
            "name": "android-keystore-file-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ProjectFileStorageResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/android-keystore-files/{android-keystore-file-slug}/uploaded": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "This is the last step of uploading an android keystore file to Bitrise. Confirm the android keystore file upload and view the file on the Code Signing tab of a specific app. Read more in our [Confirming the upload](https://devcenter.bitrise.io/api/managing-files-in-generic-file-storage/#confirming-the-file-upload) guide.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "android-keystore-file"
        ],
        "summary": "Confirm an android keystore file upload",
        "operationId": "android-keystore-file-confirm",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Android keystore file slug",
            "name": "android-keystore-file-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AndroidKeystoreFileResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/archived-builds": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List the first 1000 archived builds of a specified Bitrise app. Set parameters to filter builds:",
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "List 1000 archived builds of an app",
        "operationId": "archived-builds-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "integer",
            "description": "Listed builds should only be the ones which ran after the given date (Unix Timestamp)",
            "name": "after",
            "in": "query",
            "required": true
          },
          {
            "type": "integer",
            "description": "Listed builds should only be the ones which ran before the given date (Unix Timestamp)",
            "name": "before",
            "in": "query",
            "required": true
          },
          {
            "type": "integer",
            "description": "Limit the number of listed builds (max: 1000, default: 1000)",
            "name": "limit",
            "in": "query",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ArchivedBuildListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/bitrise.yml": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Get the full `bitrise.yml` configuration of an application, by providing the app slug. It returns the current `bitrise.yml` that is stored on bitrise.io in full, including the trigger map, the different workflows and the Steps.",
        "produces": [
          "text/plain"
        ],
        "tags": [
          "application"
        ],
        "summary": "Get bitrise.yml of a specific app",
        "operationId": "app-config-datastore-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "{the bitrise.yml in yml format}",
            "schema": {
              "type": "string"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Upload a new bitrise.yml for your application.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "app-setup"
        ],
        "summary": "Upload a new bitrise.yml for your application.",
        "operationId": "app-config-create",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "App config parameters",
            "name": "app-config",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.AppConfigRequestParam"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppConfigRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/bitrise.yml/config": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Getting the location of the application's bitrise.yaml. Requires administrator level privileges to the app.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "app-setup"
        ],
        "summary": "Getting the location of the application's bitrise.yaml",
        "operationId": "app-setup-bitrise-yml-config-get",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BitriseYMLConfigGetResponse"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "put": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Changing the location of the application's bitrise.yaml. Requires administrator level privileges to the app.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "app-setup"
        ],
        "summary": "Changing the location of the application's bitrise.yaml",
        "operationId": "app-setup-bitrise-yml-config-update",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Bitrise YML Config Update Params",
            "name": "app",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.BitriseYMLConfigUpdateParams"
            }
          }
        ],
        "responses": {
          "204": {
            "description": "No Content"
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/branches": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Lists only those branches of a specified Bitrise app that have existing builds.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "List the branches with existing builds of an app's repository",
        "operationId": "branch-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BranchListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/build-certificates": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List all the build certificates that have been uploaded to a specific app. Read more in our [Listing the uploaded iOS code signing files of an app](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#listing-the-uploaded-ios-code-signing-files-of-an-app) guide.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-certificate"
        ],
        "summary": "Get a list of the build certificates",
        "operationId": "build-certificate-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Slug of the first build certificate in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of build certificates per page is 50.",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildCertificateListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Create a temporary pre-signed upload URL for the build certificate and upload the file to AWS with a simple `curl` request. To complete the uploading process and view your files on the Code Signing tab of your app, continue with the [POST /apps/{app-slug}/build-certificates/{build-certificate-slug}/uploaded](https://api-docs.bitrise.io/#/build-certificate/build-certificate-confirm) endpoint. Read more in our [Creating and uploading an iOS code signing file](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#creating--uploading-an-ios-code-signing-file) guide.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-certificate"
        ],
        "summary": "Create a build certificate",
        "operationId": "build-certificate-create",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Build certificate parameters such as file name and its file size",
            "name": "build-certificate",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.BuildCertificateUploadParams"
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "$ref": "#/definitions/v0.BuildCertificateUploadResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/build-certificates/{build-certificate-slug}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Retrieve data of a specific build certificate. You can fetch the build certificate slug for this endpoint if you first call the [GET /apps/{app-slug}/build-certificates](https://api-docs.bitrise.io/#/build-certificate/build-certificate-list) endpoint to list all available build certificates of an app. Read more in our [Getting a specific iOS code signing file's data](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#getting-a-specific-ios-code-signing-files-data) guide.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-certificate"
        ],
        "summary": "Get a specific build certificate",
        "operationId": "build-certificate-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build certificate slug",
            "name": "build-certificate-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildCertificateDownloadResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Delete an app's build certificate. You can fetch the build certificate slug for this endpoint if you first call the [GET /apps/{app-slug}/build-certificates](https://api-docs.bitrise.io/#/build-certificate/build-certificate-list) endpoint to list all available build certificates of an app. Read more in our [Deleting an iOS code signing file](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#deleting-an-ios-code-signing-file) guide.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-certificate"
        ],
        "summary": "Delete a build certificate",
        "operationId": "build-certificate-delete",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build certificate slug",
            "name": "build-certificate-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildCertificateResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Update an uploaded build certificate's attributes. You can fetch the build certificate slug for this endpoint if you first call the [GET /apps/{app-slug}/build-certificates](https://api-docs.bitrise.io/#/build-certificate/build-certificate-list) endpoint. Read more in our [Updating an uploaded iOS code signing file](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#confirming-the-ios-code-signing-file-upload) guide.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-certificate"
        ],
        "summary": "Update a build certificate",
        "operationId": "build-certificate-update",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build certificate slug",
            "name": "build-certificate-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Build certificate parameters",
            "name": "build-certificate",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.BuildCertificateUpdateParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildCertificateResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/build-certificates/{build-certificate-slug}/uploaded": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "This is the last step of uploading a build certificate to Bitrise. Confirm the build certificate upload and view the file on the Code Signing tab of a specific app. Read more in our [Confirming the iOS code signing file upload](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#confirming-the-ios-code-signing-file-upload) guide.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-certificate"
        ],
        "summary": "Confirm a build certificate upload",
        "operationId": "build-certificate-confirm",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build certificate slug",
            "name": "build-certificate-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildCertificateResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/build-requests": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List the existing open build requests of a specified Bitrise app",
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-request"
        ],
        "summary": "List the open build requests for an app",
        "operationId": "build-request-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildRequestListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/build-requests/{build-request-slug}": {
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Update a specific build request of a specific app",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-request"
        ],
        "summary": "Update a build request",
        "operationId": "build-request-update",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build request slug",
            "name": "build-request-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Build request parameters",
            "name": "build-request",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.BuildRequestUpdateParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildRequestUpdateResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/build-workflows": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List the workflows that were triggered at any time for a given Bitrise app. Note that it might list workflows that are currently not defined in the app's `bitrise.yml` configuration - and conversely, workflows that were never triggered will not be listed even if they are defined in the `bitrise.yml` file.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "List the workflows of an app",
        "operationId": "build-workflow-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildWorkflowListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/builds": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List all the builds of a specified Bitrise app. Set parameters to filter builds: for example, you can search for builds run with a given workflow or all builds that were triggered by Pull Requests. It returns all the relevant data of the build.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "List all builds of an app",
        "operationId": "build-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "enum": [
              "running_first",
              "created_at"
            ],
            "type": "string",
            "description": "Order of builds: sort them based on when they were created or the time when they were triggered",
            "name": "sort_by",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The branch which was built",
            "name": "branch",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The name of the workflow used for the build",
            "name": "workflow",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The commit message of the build",
            "name": "commit_message",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The event that triggered the build (push, pull-request, tag)",
            "name": "trigger_event_type",
            "in": "query"
          },
          {
            "type": "integer",
            "description": "The id of the pull request that triggered the build",
            "name": "pull_request_id",
            "in": "query"
          },
          {
            "type": "integer",
            "description": "The build number",
            "name": "build_number",
            "in": "query"
          },
          {
            "type": "integer",
            "description": "List builds run after a given date (Unix Timestamp)",
            "name": "after",
            "in": "query"
          },
          {
            "type": "integer",
            "description": "List builds run before a given date (Unix Timestamp)",
            "name": "before",
            "in": "query"
          },
          {
            "maximum": 4,
            "type": "integer",
            "description": "The status of the build: not finished (0), successful (1), failed (2), aborted with failure (3), aborted with success (4)",
            "name": "status",
            "in": "query"
          },
          {
            "type": "boolean",
            "description": "Whether the builds are part of a pipeline or not",
            "name": "is_pipeline_build",
            "in": "query"
          },
          {
            "type": "string",
            "description": "Slug of the first build in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of elements per page (default: 50)",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Trigger a new build/pipeline. Specify an app slug and at least one parameter out of three: a git tag or git commit hash, a branch, or a workflow/pipeline ID. You can also set specific parameters for Pull Request builds/pipelines and define additional environment variables for your build/pipeline. [Check out our detailed guide](https://devcenter.bitrise.io/api/build-trigger/).",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "Trigger a new build/pipeline",
        "operationId": "build-trigger",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Build trigger parameters",
            "name": "build_params",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.BuildTriggerParams"
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "$ref": "#/definitions/v0.BuildTriggerRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/builds/{build-slug}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Get the specified build of a given Bitrise app. You need to provide both an app slug and a build slug. You can get the build slug either by calling the [/builds](https://api-docs.bitrise.io/#/builds/build-list) endpoint or by clicking on the build on bitrise.io and copying the slug from the URL. The endpoint returns all the relevant data of the build.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "Get a build of a given app",
        "operationId": "build-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildShowResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/builds/{build-slug}/abort": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Abort a specific build. Set an abort reason with the `abort_reason` parameter. Use the `abort_with_success` parameter to abort a build but still count it as a successful one.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "Abort a specific build",
        "operationId": "build-abort",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Build abort parameters",
            "name": "build-abort-params",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.BuildAbortParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildAbortResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "429": {
            "description": "Too Many Requests",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/builds/{build-slug}/artifacts": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List all build artifacts that have been generated for an app's build. This endpoint can retrieve artifacts from the archive as well. You can use the created build artifact slugs from the response output to retrieve data of a specific build artifact with the [GET/apps/](https://api-docs.bitrise.io/#/build-artifact/artifact-show) endpoint or update a build artifact with the [PATCH/apps](https://api-docs.bitrise.io/#/build-artifact/artifact-update) endpoint.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-artifact"
        ],
        "summary": "Get a list of all build artifacts",
        "operationId": "artifact-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Slug of the first build artifact in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of build artifacts per page is 50.",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ArtifactListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/builds/{build-slug}/artifacts/{artifact-slug}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Retrieve data of a specific build artifact. The endpoint can retrieve archived artifacts as well. The response output contains a time-limited download url (expires in 10 minutes) and a public install-page URL. You can view the build artifact with both URLs, but the public install-page url will not work unless you [enable it](https://devcenter.bitrise.io/tutorials/deploy/bitrise-app-deployment/#enabling-public-page-for-the-app).",
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-artifact"
        ],
        "summary": "Get a specific build artifact",
        "operationId": "artifact-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Artifact slug",
            "name": "artifact-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "integer",
            "description": "Setting this will result in a redirect to the artifact download location",
            "name": "download",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ArtifactShowResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Delete a build artifact of an app's build. The required parameters are app slug, build slug and artifact slug. You can fetch the build artifact slug if you first list all build artifacts of an app with the [/apps/](https://api-docs.bitrise.io/#/build-artifact/artifact-list) endpoint.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-artifact"
        ],
        "summary": "Delete a build artifact",
        "operationId": "artifact-delete",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Artifact slug",
            "name": "artifact-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ArtifactDeleteResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Update the `is_public_page_enabled` attribute of your app's build. The required parameters are app slug, build slug and artifact slug. You can fetch the build artifact slug if you first list all build artifacts of an app with the [GET /apps/](https://api-docs.bitrise.io/#/build-artifact/artifact-list) endpoint.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "build-artifact"
        ],
        "summary": "Update a build artifact",
        "operationId": "artifact-update",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Artifact slug",
            "name": "artifact-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Artifact parameters",
            "name": "artifact-params",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.ArtifactUpdateParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ArtifactShowResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/builds/{build-slug}/bitrise.yml": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Get the bitrise.yml file of one of the builds of a given app. This will return the `bitrise.yml` configuration with which the build ran. You can compare it to [the current bitrise.yml configuration](https://api-docs.bitrise.io/#/application/app-config-datastore-show) of the app.",
        "produces": [
          "text/plain"
        ],
        "tags": [
          "builds"
        ],
        "summary": "Get the bitrise.yml of a build",
        "operationId": "build-bitrise-yml-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "{the bitrise.yml in yml format}",
            "schema": {
              "type": "string"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/builds/{build-slug}/log": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Get the build log of a specified build of a Bitrise app. You can get the build slug either by calling the [/builds](https://api-docs.bitrise.io/#/builds/build-list) endpoint or by clicking on the build on bitrise.io and copying the slug from the URL. Preview of the log is returned in `log_chunks` field in JSON format. You can download the full raw log in txt by using the signed url returned in `expiring_raw_log_url`. Be aware that this url is expiring in 10 minutes!",
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "Get the build log of a build",
        "operationId": "build-log",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/builds/{build-slug}/log/summary": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Get the workflows and steps of a build with their status, timing and versions. For failed or aborted steps, `errors` holds why the step failed; for skipped steps, `status_reason` holds why it was skipped. The summary is updated as steps finish, so it can be polled while the build is running.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "Get the step summary of a build",
        "operationId": "build-log-summary",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "array",
            "items": {
              "enum": [
                "not_started",
                "started",
                "success",
                "failed",
                "failed_skippable",
                "preparation_failed",
                "skipped",
                "skipped_with_run_if",
                "aborted",
                "aborted_with_custom_timeout",
                "aborted_with_no_output"
              ],
              "type": "string"
            },
            "collectionFormat": "multi",
            "description": "Step statuses to keep, e.g. `status=failed\u0026status=aborted_with_custom_timeout` (a comma-separated list also works). Only steps with one of these statuses are returned, and workflows without any are left out. Failed and aborted steps carry their failure reason in `errors`.",
            "name": "status",
            "in": "query"
          },
          {
            "type": "string",
            "description": "Only return the runs of this step (for example `xcode-test`). A step used several times in a build is returned once per run, each with its own `uuid`.",
            "name": "step_id",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/service.dto.BuildLogSummaryRespModel"
            }
          },
          "400": {
            "description": "Bad request - unknown step status in the `status` filter",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found - build does not exist, or it has no step summary yet",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/builds/{build-slug}/rebuild": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Rebuild a finished build with the same parameters and workflow as the original build. Set `is_remote` to enable remote access for the new build, which requires permission for remote access on the app.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "Rebuild a build",
        "operationId": "build-rebuild",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Build rebuild parameters",
            "name": "build-rebuild-params",
            "in": "body",
            "schema": {
              "type": "object",
              "properties": {
                "is_remote": {
                  "description": "Enable remote access for the new build. When omitted, the build is rebuilt without remote access.",
                  "type": "boolean",
                  "default": false
                }
              }
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "$ref": "#/definitions/v0.BuildTriggerRespModel"
            }
          },
          "400": {
            "description": "Bad request - the build is not finished yet",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden - no permission to run builds, or to enable remote access",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/builds/{build-slug}/test-results": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Get the test suites and test cases a finished build reported, with their status, duration and failure message. Requires a plan that includes test reports. With any filter or `limit`, test suites without matching test cases are left out; the counts of a test suite always cover all of its test cases.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "Get the test results of a build",
        "operationId": "build-test-results",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "array",
            "items": {
              "enum": [
                "passed",
                "failed",
                "skipped",
                "error"
              ],
              "type": "string"
            },
            "collectionFormat": "multi",
            "description": "Test case statuses to keep, e.g. `status=failed\u0026status=error` for every test that needs fixing (a comma-separated list also works). A test that failed and then passed on a retry has status `passed` and `flaky` true.",
            "name": "status",
            "in": "query"
          },
          {
            "type": "string",
            "description": "Only return test cases under the test suite with this exact name, at any nesting level.",
            "name": "suite",
            "in": "query"
          },
          {
            "type": "string",
            "description": "Only return test cases with this exact class name.",
            "name": "class_name",
            "in": "query"
          },
          {
            "type": "boolean",
            "description": "Only return test cases that are (true) or are not (false) flaky in this build. A test case is flaky when its runs ended with different statuses.",
            "name": "flaky",
            "in": "query"
          },
          {
            "enum": [
              "duration",
              "name",
              "status"
            ],
            "type": "string",
            "description": "Sort the test cases within each test suite. Ascending `status` lists `error`, `failed`, `skipped`, then `passed`.",
            "name": "sort_by",
            "in": "query"
          },
          {
            "enum": [
              "asc",
              "desc"
            ],
            "type": "string",
            "default": "asc",
            "description": "Direction of `sort_by`. Only valid together with `sort_by`.",
            "name": "sort_order",
            "in": "query"
          },
          {
            "maximum": 1000,
            "minimum": 1,
            "type": "integer",
            "description": "Maximum number of test cases to return, counted in response order across all test suites.",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/service.dto.BuildTestResultsRespModel"
            }
          },
          "400": {
            "description": "Bad request - the build is not finished yet, or a filter value is invalid",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized - no valid personal access token or workspace API token",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden - the plan of the workspace does not include test reports",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found - build does not exist, or user is not authorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "502": {
            "description": "Bad gateway - the test results could not be fetched, try again later",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/cache-items": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all the available cache items that the builds of the app created via the save-cache step.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "key-value-cache"
        ],
        "summary": "List the key-value cache items belonging to an app",
        "operationId": "cache-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Getting cache items created before the given parameter (RFC3339 time format, default: now)",
            "name": "next",
            "in": "query"
          },
          {
            "type": "integer",
            "description": "Max number of elements per page (default: 100)",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.CacheItemListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Deletes all key-value cache items created by the builds of an app. Deleted cache items are no longer accessible and cannot be restored.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "key-value-cache"
        ],
        "summary": "Deletes all key-value cache items belonging to an app",
        "operationId": "cache-item-delete-all",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK"
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/cache-items/{cache-item-id}": {
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Deletes a key-value cache item. Deleted cache items are no longer accessible and cannot be restored.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "key-value-cache"
        ],
        "summary": "Deletes a key-value cache item",
        "operationId": "cache-item-delete",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "The ID of the cache item to be deleted",
            "name": "cache-item-id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK"
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/cache-items/{cache-item-id}/download": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Gets a download URL of a cache item.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "key-value-cache"
        ],
        "summary": "Gets the download URL of a key-value cache item",
        "operationId": "cache-item-download",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "The ID of the cache item to be downloaded",
            "name": "cache-item-id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.CacheItemDownloadResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/change-connection-type": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Change the connection type of an app",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Change the connection type of an app",
        "operationId": "app-change-connection-type",
        "parameters": [
          {
            "type": "string",
            "description": "Slug of the app",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Connection type data",
            "name": "connection",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "required": [
                "connection_type"
              ],
              "properties": {
                "connection_type": {
                  "description": "Type of connection (github-app or github)",
                  "type": "string"
                }
              }
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created"
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/finish": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Save the application after registering it on Bitrise and registering an SSH key (and, optionally, adding a webhook). With this endpoint you can define the initial configuration, define application-level environment variables, determine the project type, and set an Organization to be the owner of the app. Read more about the app registration process in our [detailed guide](https://devcenter.bitrise.io/api/adding-and-managing-apps/#adding-a-new-app).",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "app-setup"
        ],
        "summary": "Save the application at the end of the app registration process",
        "operationId": "app-finish",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "App finish parameters",
            "name": "app",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.AppFinishParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppFinishRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/generic-project-files": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List all the generic project files that have been uploaded to a specific app. Read more in our [Listing the uploaded files of an app](https://devcenter.bitrise.io/api/managing-files-in-generic-file-storage/#listing-the-uploaded-files-of-an-app) guide.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "generic-project-file"
        ],
        "summary": "Get a list of the generic project files",
        "operationId": "generic-project-file-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Slug of the first generic project file in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of build certificates per page is 50.",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ProjectFileStorageListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Create a temporary pre-signed upload URL (expires in 10 minutes) for the generic project file and upload it to AWS with a simple `curl` request. To complete the uploading process and view your files on the Code Signing tab of your app, continue with the [POST /apps/{app-slug}/generic-project-files/{generic-project-file-slug}/uploaded](https://api-docs.bitrise.io/#/generic-project-file/generic-project-file-confirm) endpoint. Read more in our [Creating and uploading files to Generic File Storage](https://devcenter.bitrise.io/api/managing-files-in-generic-file-storage/#creating-and-uploading-files-to-generic-file-storage) guide.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "generic-project-file"
        ],
        "summary": "Create a generic project file",
        "operationId": "generic-project-files-create",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Generic project file parameters",
            "name": "generic-project-file",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.ProjectFileStorageUploadParams"
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "$ref": "#/definitions/v0.ProjectFileStorageUploadResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/generic-project-files/{generic-project-file-slug}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Retrieve data of a specific generic project file to check its attributes and optionally modify them with the [PATCH /apps/](https://api-docs.bitrise.io/#/generic-project-file/generic-project-file-update) endpoint. Read more in our [Retrieving a specific file's data](https://devcenter.bitrise.io/api/managing-files-in-generic-file-storage/#retrieving-a-specific-files-data) guide.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "generic-project-file"
        ],
        "summary": "Get a specific generic project file",
        "operationId": "generic-project-file-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Generic project file slug",
            "name": "generic-project-file-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ProjectFileStorageDownloadResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Delete an app's generic project file. You can fetch an app's generic project file slug if you first list all the uploaded files with the [GET /apps/{app-slug}/generic-project-files](https://api-docs.bitrise.io/#/generic-project-file/generic-project-file-list) endpoint. Read more in our [Deleting a file](https://devcenter.bitrise.io/api/managing-files-in-generic-file-storage/#deleting-a-file) guide.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "generic-project-file"
        ],
        "summary": "Delete a generic project file",
        "operationId": "generic-project-file-delete",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Generic project file slug",
            "name": "generic-project-file-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ProjectFileStorageResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Update a generic project file's attributes. You can fetch an app's generic project file slug if you first list all the uploaded files with the [GET /apps/{app-slug}/generic-project-files](https://api-docs.bitrise.io/#/generic-project-file/generic-project-file-list) endpoint. Read more in our [Updating an uploaded file](https://devcenter.bitrise.io/api/managing-files-in-generic-file-storage/#updating-an-uploaded-file) guide.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "generic-project-file"
        ],
        "summary": "Update a generic project file",
        "operationId": "generic-project-file-update",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Generic project file slug",
            "name": "generic-project-file-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Generic project file parameters",
            "name": "generic-project-file",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.ProjectFileStorageDocumentUpdateParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ProjectFileStorageResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/generic-project-files/{generic-project-file-slug}/uploaded": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "This is the last step of uploading a generic project file to Bitrise. Confirm the generic project file upload and view the file on the Code Signing tab of a specific app. Read more in our [Confirming the upload](https://devcenter.bitrise.io/api/managing-files-in-generic-file-storage/#confirming-the-file-upload) guide.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "generic-project-file"
        ],
        "summary": "Confirm a generic project file upload",
        "operationId": "generic-project-file-confirm",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Generic project file slug",
            "name": "generic-project-file-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ProjectFileStorageResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/github-app-connection-configuration": {
      "put": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Change Github app connection configuration of an app",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Change Github app connection configuration of an app",
        "operationId": "app-change-github-app-connection-configuration",
        "parameters": [
          {
            "type": "string",
            "description": "Slug of the app",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Github app connection configuration data",
            "name": "connection",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "required": [
                "use_full_permission_set"
              ],
              "properties": {
                "use_full_permission_set": {
                  "type": "boolean"
                }
              }
            }
          }
        ],
        "responses": {
          "204": {
            "description": "No Content"
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/github-app-connection-configuration/update-linked-repositories": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Change the linked repositories of a Github app connection",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Change the linked repositories of a Github app connection",
        "operationId": "app-change-linked-repositories",
        "parameters": [
          {
            "type": "string",
            "description": "Slug of the app",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Linked repositories data",
            "name": "linked-repositories",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "properties": {
                "repositories": {
                  "description": "List of repository full names (org/repo) to be linked",
                  "type": "array",
                  "items": {
                    "type": "string"
                  }
                },
                "unlimited_repo_access": {
                  "type": "boolean"
                }
              }
            }
          }
        ],
        "responses": {
          "204": {
            "description": "No Content"
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/outgoing-webhooks": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List all the outgoing webhooks registered for a specified Bitrise app. This returns all the relevant data of the webhook, including the slug of the webhook and its URL.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "outgoing-webhook"
        ],
        "summary": "List the outgoing webhooks of an app",
        "operationId": "outgoing-webhook-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Slug of the first webhook in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of elements per page (default: 50)",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppWebhookListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Create an outgoing webhook for a specified Bitrise app: this can be used to send build events to a specified URL with custom headers. Currently, only build events can trigger outgoing webhooks.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "outgoing-webhook"
        ],
        "summary": "Create an outgoing webhook for an app",
        "operationId": "outgoing-webhook-create",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "App webhook creation params",
            "name": "app-webhook-create-params",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.AppWebhookCreateParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppWebhookCreatedResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/outgoing-webhooks/{app-webhook-slug}": {
      "put": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Update an existing outgoing webhook (URL, events, secrets and headers) for a specified Bitrise app. Even if you do not want to change one of the parameters, you still have to provide that parameter as well: simply use its existing value.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "outgoing-webhook"
        ],
        "summary": "Update an outgoing webhook of an app",
        "operationId": "outgoing-webhook-update",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "App webhook slug",
            "name": "app-webhook-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "App webhook update params",
            "name": "app-webhook-update-params",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.AppWebhookUpdateParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppWebhookResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Delete an existing outgoing webhook for a specified Bitrise app.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "outgoing-webhook"
        ],
        "summary": "Delete an outgoing webhook of an app",
        "operationId": "outgoing-webhook-delete",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "App webhook slug",
            "name": "app-webhook-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppWebhookDeletedResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/outgoing-webhooks/{app-webhook-slug}/delivery-items": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all the delivery items of an outgoing webhook of a Bitrise application",
        "produces": [
          "application/json"
        ],
        "tags": [
          "webhook-delivery-item"
        ],
        "summary": "List the webhook delivery items of an app",
        "operationId": "webhook-delivery-item-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "App webhook slug",
            "name": "app-webhook-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Slug of the first delivery item in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of elements per page (default: 50)",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.WebhookDeliveryItemShowResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/outgoing-webhooks/{app-webhook-slug}/delivery-items/{webhook-delivery-item-slug}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Get the specified delivery item of an outgoing webhook of a Bitrise application",
        "produces": [
          "application/json"
        ],
        "tags": [
          "webhook-delivery-item"
        ],
        "summary": "Get a specific delivery item of a webhook",
        "operationId": "webhook-delivery-item-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "App webhook slug",
            "name": "app-webhook-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Webhook delivery item slug",
            "name": "webhook-delivery-item-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.WebhookDeliveryItemResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/outgoing-webhooks/{app-webhook-slug}/delivery-items/{webhook-delivery-item-slug}/redeliver": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Re-deliver the delivery item of a specified webhook of a Bitrise application",
        "produces": [
          "application/json"
        ],
        "tags": [
          "webhook-delivery-item"
        ],
        "summary": "Re-deliver the webhook delivery items of an app",
        "operationId": "webhook-delivery-item-redeliver",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "App webhook slug",
            "name": "app-webhook-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Webhook delivery item slug",
            "name": "webhook-delivery-item-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/pipelines": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List all the pipelines and standalone builds of a specified Bitrise app. Set parameters to filter pipelines: for example, you can search for pipelines/standalone builds run with a given workflow name or all pipelines/standalone builds that were triggered by Pull Requests. It returns all the relevant data of the pipelines/standalone builds.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "pipelines"
        ],
        "summary": "List all pipelines and standalone builds of an app",
        "operationId": "pipeline-list",
        "parameters": [
          {
            "type": "string",
            "description": "List pipelines/standalone builds run after a given date (RFC3339 time format)",
            "name": "after",
            "in": "query"
          },
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "List pipelines/standalone builds run before a given date (RFC3339 time format) - was called 'next' earlier",
            "name": "before",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The branch which was built",
            "name": "branch",
            "in": "query"
          },
          {
            "type": "integer",
            "description": "The pipeline/standalone build number",
            "name": "build_number",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The commit message of the pipeline/standalone build",
            "name": "commit_message",
            "in": "query"
          },
          {
            "type": "integer",
            "description": "Max number of elements per page - default: 10",
            "name": "limit",
            "in": "query"
          },
          {
            "type": "string",
            "description": "List pipelines/standalone builds run before a given date (RFC3339 time format) - deprecated",
            "name": "next",
            "in": "query"
          },
          {
            "type": "string",
            "description": "Name of the pipeline",
            "name": "pipeline",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The status of the pipeline/standalone build: on_hold, running, succeeded, failed, aborted, succeeded_with_abort",
            "name": "status",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The event that triggered the pipeline/standalone build (push, pull-request, tag)",
            "name": "trigger_event_type",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The name of the workflow used for the pipeline/standalone build",
            "name": "workflow",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.PipelineListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/pipelines/{pipeline-id}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Get the specified pipeline of a given Bitrise app. You need to provide both an app slug and a pipeline id. You can get the pipeline id either by calling the [/pipelines](https://api-docs.bitrise.io/#/pipelines/pipeline-list) endpoint or by clicking on the pipeline on bitrise.io and copying the id from the URL. The endpoint returns all the relevant data of the pipeline.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "pipelines"
        ],
        "summary": "Get a pipeline of a given app",
        "operationId": "pipeline-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Pipeline id",
            "name": "pipeline-id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.PipelineShowResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/pipelines/{pipeline-id}/abort": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "Aborts a pipeline. You need to provide the app slug and the id of the pipeline. You can add an abort reason, choose to skip notifications and make the abort with success state.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "pipelines"
        ],
        "summary": "Aborts a pipeline",
        "operationId": "pipeline-abort",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Pipeline id",
            "name": "pipeline-id",
            "in": "path",
            "required": true
          },
          {
            "description": "Pipeline abort parameters",
            "name": "pipeline-abort-params",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.PipelineAbortParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK"
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/pipelines/{pipeline-id}/rebuild": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Rebuilds a pipeline. You can rebuild the whole pipeline or only the unsuccessful and subsequent workflows by setting the partial flag to true.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "pipelines"
        ],
        "summary": "Rebuilds a pipeline",
        "operationId": "pipeline-rebuild",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Pipeline id",
            "name": "pipeline-id",
            "in": "path",
            "required": true
          },
          {
            "description": "Pipeline rebuild parameters",
            "name": "pipeline-rebuild-params",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.PipelineRebuildParams"
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created"
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "412": {
            "description": "Precondition Failed",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/provisioning-profiles": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List all the provisioning profiles that have been uploaded to a specific app. Read more in our [Listing the uploaded iOS code signing files of an app](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#listing-the-uploaded-ios-code-signing-files-of-an-app) guide.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "provisioning-profile"
        ],
        "summary": "Get a list of the provisioning profiles",
        "operationId": "provisioning-profile-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Slug of the first provisioning profile in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of elements per page (default: 50)",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ProvisionProfileListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Create a temporary pre-signed upload URL (expires in 10 minutes) for the provisioning profile and upload it to AWS with a simple `curl` request. To complete the upload process, continue with the [POST /apps/{app-slug}/provisioning-profiles/{provisioning-profile-slug}/uploaded](https://api-docs.bitrise.io/#/provisioning-profile/provisioning-profile-confirm) endpoint. Read more in our [Creating and uploading an iOS code signing file](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#creating--uploading-an-ios-code-signing-file) guide.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "provisioning-profile"
        ],
        "summary": "Create a provisioning profile",
        "operationId": "provisioning-profile-create",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Provisioning profile parameters such as file name and file size",
            "name": "provisioning-profile",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.ProvisionProfileUploadParams"
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "$ref": "#/definitions/v0.ProvisionProfileUploadResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/provisioning-profiles/{provisioning-profile-slug}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Retrieve data of a specific provisioning profile. You can fetch the provisioning profile's slug if you call the [GET /apps/{app-slug}/provisioning-profiles](https://api-docs.bitrise.io/#/provisioning-profile/provisioning-profile-list) endpoint. Read more in our [Getting a specific iOS code signing file's data](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#getting-a-specific-ios-code-signing-files-data) guide.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "provisioning-profile"
        ],
        "summary": "Get a specific provisioning profile",
        "operationId": "provisioning-profile-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Provisioning profile slug",
            "name": "provisioning-profile-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ProvisionProfileDownloadResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Delete an app's provisioning profile. You can fetch the provisioning profile's slug if you call the [GET /apps/{app-slug}/provisioning-profiles](https://api-docs.bitrise.io/#/provisioning-profile/provisioning-profile-list) endpoint. Read more in our [Deleting an iOS code signing file](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#deleting-an-ios-code-signing-file) guide.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "provisioning-profile"
        ],
        "summary": "Delete a provisioning profile",
        "operationId": "provisioning-profile-delete",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Provisioning profile slug",
            "name": "provisioning-profile-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ProvisionProfileResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Update an uploaded provisioning profile's attributes. You can fetch the provisioning profile's slug if you call the [GET /apps/{app-slug}/provisioning-profiles](https://api-docs.bitrise.io/#/provisioning-profile/provisioning-profile-list) endpoint. Read more in our [Updating an uploaded iOS code signing file](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#confirming-the-ios-code-signing-file-upload) guide.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "provisioning-profile"
        ],
        "summary": "Update a provisioning profile",
        "operationId": "provisioning-profile-update",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Provisioning profile slug",
            "name": "provisioning-profile-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Provisioning profile parameters",
            "name": "provisioning-profile",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.ProvProfileDocumentUpdateParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ProvisionProfileResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/provisioning-profiles/{provisioning-profile-slug}/uploaded": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "This is the last step of the upload process. Confirm the provisioning profile upload and view the file on the Code Signing tab of a specific app. Read more in our [Confirming the iOS code signing file upload](https://devcenter.bitrise.io/api/managing-ios-code-signing-files/#confirming-the-ios-code-signing-file-upload) guide.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "provisioning-profile"
        ],
        "summary": "Confirm a provisioning profile upload",
        "operationId": "provisioning-profile-confirm",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Provisioning profile slug",
            "name": "provisioning-profile-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ProvisionProfileResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/quarantined-tests": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List the tests quarantined on an app, oldest first. Quarantined tests are excluded from the test runs of builds the quarantine applies to.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "test-quarantine"
        ],
        "summary": "List the quarantined tests of an app",
        "operationId": "quarantined-test-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/service.dto.QuarantinedTestsRespModel"
            }
          },
          "401": {
            "description": "Unauthorized - no valid personal access token or workspace API token",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found - app does not exist, or user is not authorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Quarantine a test case of an app. The test is identified by `test_case_identifier` when the test report provides one, otherwise by its name, suite names and class name. Requires permission to run builds and a plan that includes test quarantine.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "test-quarantine"
        ],
        "summary": "Quarantine a test",
        "operationId": "quarantined-test-create",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "The test to quarantine",
            "name": "quarantined-test",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "required": [
                "test_case_name",
                "test_suite_name"
              ],
              "properties": {
                "build_slug": {
                  "description": "Slug of a build of the app the test failed in. When omitted, the test is recorded as quarantined from the API.",
                  "type": "string"
                },
                "class_name": {
                  "type": "string"
                },
                "comment": {
                  "type": "string"
                },
                "filters": {
                  "$ref": "#/definitions/service.dto.QuarantinedTestFilters"
                },
                "test_case_identifier": {
                  "type": "string"
                },
                "test_case_name": {
                  "type": "string"
                },
                "test_suite_name": {
                  "description": "Names of the test suites containing the test case, outermost first",
                  "type": "array",
                  "items": {
                    "type": "string"
                  }
                }
              }
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "$ref": "#/definitions/service.dto.QuarantinedTest"
            }
          },
          "401": {
            "description": "Unauthorized - no valid personal access token or workspace API token",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden - user cannot run builds on the app, or the plan of the workspace does not include test quarantine",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found - app does not exist, or user is not authorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "409": {
            "description": "Conflict - the test is already quarantined; the response contains it in `quarantined_test`",
            "schema": {
              "type": "object",
              "properties": {
                "error_msg": {
                  "type": "string"
                },
                "quarantined_test": {
                  "$ref": "#/definitions/service.dto.QuarantinedTest"
                }
              }
            }
          },
          "422": {
            "description": "Unprocessable entity - a parameter is missing or invalid, or `build_slug` is not a build of the app",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/quarantined-tests/{quarantined-test-id}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Get a quarantined test of an app",
        "produces": [
          "application/json"
        ],
        "tags": [
          "test-quarantine"
        ],
        "summary": "Get a quarantined test",
        "operationId": "quarantined-test-show",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Quarantined test ID",
            "name": "quarantined-test-id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/service.dto.QuarantinedTest"
            }
          },
          "401": {
            "description": "Unauthorized - no valid personal access token or workspace API token",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found - app or quarantined test does not exist, or user is not authorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Remove a test from quarantine, so it is included in test runs again. Requires permission to run builds and a plan that includes test quarantine.",
        "tags": [
          "test-quarantine"
        ],
        "summary": "Remove a test from quarantine",
        "operationId": "quarantined-test-delete",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Quarantined test ID",
            "name": "quarantined-test-id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "204": {
            "description": "No content"
          },
          "401": {
            "description": "Unauthorized - no valid personal access token or workspace API token",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden - user cannot run builds on the app, or the plan of the workspace does not include test quarantine",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found - app or quarantined test does not exist, or user is not authorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Update the comment or the filters of a quarantined test. Only the fields sent are changed. Send `filters` as null to clear both filters, or `filters.branches` or `filters.targets` as null to clear one. Requires permission to run builds and a plan that includes test quarantine.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "test-quarantine"
        ],
        "summary": "Update a quarantined test",
        "operationId": "quarantined-test-update",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Quarantined test ID",
            "name": "quarantined-test-id",
            "in": "path",
            "required": true
          },
          {
            "description": "The fields to change",
            "name": "quarantined-test",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "properties": {
                "comment": {
                  "type": "string"
                },
                "filters": {
                  "allOf": [
                    {
                      "$ref": "#/definitions/service.dto.QuarantinedTestFilters"
                    }
                  ],
                  "x-nullable": true
                }
              }
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/service.dto.QuarantinedTest"
            }
          },
          "401": {
            "description": "Unauthorized - no valid personal access token or workspace API token",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden - user cannot run builds on the app, or the plan of the workspace does not include test quarantine",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found - app or quarantined test does not exist, or user is not authorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "422": {
            "description": "Unprocessable entity - a parameter is invalid",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/register-ssh-key": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Add an SSH-key to a specific app. After creating an app, you need to register the SSH key so that Bitrise will be able to access and clone your repository during the build process. This requires the app slug of your newly created app.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "app-setup"
        ],
        "summary": "Add an SSH-key to a specific app",
        "operationId": "ssh-key-create",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "SSH key parameters",
            "name": "ssh-key",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.SSHKeyUploadParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.SSHKeyRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/register-webhook": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "[Register an incoming webhook](https://devcenter.bitrise.io/api/incoming-and-outgoing-webhooks/#incoming-webhooks) for a specific application. You can do this during the app registration process or at any other time in an app's life. When calling this endpoint, a webhook is registered at your git provider: this is necessary to automatically trigger builds on Bitrise.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "app-setup"
        ],
        "summary": "Register an incoming webhook for a specific application",
        "operationId": "app-webhook-create",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.WebhookRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/repository-authorization": {
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Remove repository authorization of an app",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Remove repository authorization of an app",
        "operationId": "app-remove-repository-authorization",
        "parameters": [
          {
            "type": "string",
            "description": "Slug of the app",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "204": {
            "description": "No Content"
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/roles/{role-name}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Lists group roles for an app",
        "operationId": "app-roles-query",
        "parameters": [
          {
            "type": "string",
            "description": "Slug of the app",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "enum": [
              "admin",
              "manager",
              "member",
              "platform_engineer"
            ],
            "type": "string",
            "description": "Name of the role being queried, supported values are: admin, manager (equals developer), member (equals tester/qa) and platform_engineer",
            "name": "role-name",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "List of group slugs",
            "schema": {
              "allOf": [
                {
                  "type": "object"
                },
                {
                  "type": "object",
                  "properties": {
                    "groups": {
                      "type": "array",
                      "items": {
                        "type": "string"
                      }
                    }
                  }
                }
              ]
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "put": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Replaces the groups for a given role on an app. Only the given groups will be present for a role on the app after this call.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Replaces group roles for an app",
        "operationId": "app-roles-update",
        "parameters": [
          {
            "type": "string",
            "description": "Slug of the app",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "enum": [
              "admin",
              "manager",
              "member",
              "platform_engineer"
            ],
            "type": "string",
            "description": "Name of the role being modified, supported values are: admin, manager (equals developer), member (equals tester/qa), and platform_engineer",
            "name": "role-name",
            "in": "path",
            "required": true
          },
          {
            "description": "List of group slugs",
            "name": "groups",
            "in": "body",
            "required": true,
            "schema": {
              "allOf": [
                {
                  "type": "object"
                },
                {
                  "type": "object",
                  "properties": {
                    "groups": {
                      "type": "array",
                      "items": {
                        "type": "string"
                      }
                    }
                  }
                }
              ]
            }
          }
        ],
        "responses": {
          "200": {
            "description": "List of group slugs",
            "schema": {
              "allOf": [
                {
                  "type": "object"
                },
                {
                  "type": "object",
                  "properties": {
                    "groups": {
                      "type": "array",
                      "items": {
                        "type": "string"
                      }
                    }
                  }
                }
              ]
            }
          },
          "422": {
            "description": "Unprocessable Entity",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/secrets": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List the application secrets (with no values). Requires administrator level privileges to the app.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "List the application secrets (with no values)",
        "operationId": "secret-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Ok",
            "schema": {
              "type": "object",
              "properties": {
                "secrets": {
                  "type": "array",
                  "items": {
                    "$ref": "#/definitions/service.dto.CreatedSecretNoValue"
                  }
                }
              }
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Create a new app secret",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "Create a new app secret",
        "operationId": "app-secret-create",
        "parameters": [
          {
            "type": "string",
            "description": "app slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "secret data",
            "name": "secret",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "required": [
                "name",
                "value"
              ],
              "properties": {
                "expand_in_step_inputs": {
                  "type": "boolean"
                },
                "is_exposed_for_pull_requests": {
                  "type": "boolean"
                },
                "is_protected": {
                  "type": "boolean"
                },
                "name": {
                  "type": "string"
                },
                "value": {
                  "type": "string"
                }
              }
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "$ref": "#/definitions/service.dto.CreatedSecretNoValue"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/secrets/{secret-name}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Get a single app secret by name, including the value if not protected",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "Get a single app secret by name",
        "operationId": "app-secrets-show",
        "parameters": [
          {
            "type": "string",
            "description": "app slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "secret name",
            "name": "secret-name",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Ok",
            "schema": {
              "allOf": [
                {
                  "$ref": "#/definitions/service.dto.CreatedSecretNoValue"
                },
                {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  }
                }
              ]
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "put": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Upsert an application secret. Requires administrator level privileges to the app.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "Upsert an application secret",
        "operationId": "secret-upsert",
        "deprecated": true,
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Secret name",
            "name": "secret-name",
            "in": "path",
            "required": true
          },
          {
            "description": "Secret parameters",
            "name": "app",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "properties": {
                "expand_in_step_inputs": {
                  "description": "Replace variable in inputs? https://devcenter.bitrise.io/en/references/steps-reference/step-inputs-reference.html#step-input-properties",
                  "type": "boolean"
                },
                "is_exposed_for_pull_requests": {
                  "description": "Expose for Pull Requests?",
                  "type": "boolean"
                },
                "is_protected": {
                  "description": "Secret marked as protected?",
                  "type": "boolean"
                },
                "value": {
                  "description": "Value of the secret",
                  "type": "string"
                }
              }
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created"
          },
          "204": {
            "description": "No Content"
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Delete an application secret. Requires administrator level privileges to the app.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "Delete an application secret",
        "operationId": "secret-delete",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Secret name",
            "name": "secret-name",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "204": {
            "description": "No Content"
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      },
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Update an existing app secret. If the secret is protected, only its value can be overridden.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "Update an existing app secret",
        "operationId": "app-secret-update",
        "parameters": [
          {
            "type": "string",
            "description": "app slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "secret name",
            "name": "secret-name",
            "in": "path",
            "required": true
          },
          {
            "description": "secret data",
            "name": "secret",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "properties": {
                "expand_in_step_inputs": {
                  "type": "boolean"
                },
                "is_exposed_for_pull_requests": {
                  "type": "boolean"
                },
                "is_protected": {
                  "type": "boolean"
                },
                "value": {
                  "type": "string"
                }
              }
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Ok",
            "schema": {
              "allOf": [
                {
                  "$ref": "#/definitions/service.dto.CreatedSecretNoValue"
                },
                {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  }
                }
              ]
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/secrets/{secret-name}/value": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Get the value of an (unprotected) application secrets. Requires administrator level privileges to the app.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "Get the value of an (unprotected) application secrets",
        "operationId": "secret-value-get",
        "deprecated": true,
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "Secret name",
            "name": "secret-name",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "type": "object",
              "properties": {
                "value": {
                  "type": "string"
                }
              }
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/service-credential-user": {
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Remove service credential user of an app",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Remove service credential user of an app",
        "operationId": "app-remove-service-credential-user",
        "parameters": [
          {
            "type": "string",
            "description": "Slug of the app",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "204": {
            "description": "No Content"
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/test-devices": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          },
          {
            "AddonAuthToken": []
          }
        ],
        "description": "List registered test devices of all members of a specified Bitrise app",
        "produces": [
          "application/json"
        ],
        "tags": [
          "test-devices"
        ],
        "summary": "List the test devices for an app",
        "operationId": "test-device-list",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.TestDeviceListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/apps/{app-slug}/update-email-notifications": {
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Updates the app's email notification settings with parameters",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Updates the app's notification settings",
        "operationId": "app-notifications",
        "parameters": [
          {
            "type": "string",
            "description": "App slug",
            "name": "app-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "App notification settings parameters",
            "name": "notification_settings_params",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.AppNotificationSettingsParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppNotificationSettingsUpdateResponse"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/available-stacks": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all available stacks and their metadata.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "configuration"
        ],
        "summary": "List available stacks",
        "operationId": "available-stacks-list",
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/service.dto.AvailableStacksRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/builds": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all the Bitrise builds that can be accessed with the authenticated account. Filter builds based on their owner, using the owner slug, or the status of the build.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "List all builds",
        "operationId": "build-list-all",
        "parameters": [
          {
            "type": "string",
            "description": "The slug of the owner of the app or apps",
            "name": "owner_slug",
            "in": "query"
          },
          {
            "type": "boolean",
            "description": "Indicates whether the build has started yet (true: the build hasn't started)",
            "name": "is_on_hold",
            "in": "query"
          },
          {
            "maximum": 4,
            "type": "integer",
            "description": "The status of the build: not finished (0), successful (1), failed (2), aborted with failure (3), aborted with success (4)",
            "name": "status",
            "in": "query"
          },
          {
            "type": "string",
            "description": "Slug of the first build in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of elements per page (default: 50)",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.BuildListAllResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/builds/{build-slug}/ai-summary": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Get AI-generated summary of a failed build. Only available after a build has failed and if the AI build summary feature is enabled in the Project Settings.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "builds"
        ],
        "summary": "Get AI-generated summary of a failed build",
        "operationId": "build-ai-summary",
        "parameters": [
          {
            "type": "string",
            "description": "Build slug",
            "name": "build-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK"
          },
          "404": {
            "description": "Not found - build does not exist, user is not authorized, or no AI summary is available",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/groups/{group-slug}/add_member": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Add a member to a group",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "groups"
        ],
        "summary": "Add a member to a group",
        "operationId": "group-member-add",
        "parameters": [
          {
            "type": "string",
            "description": "group slug",
            "name": "group-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "member data",
            "name": "member",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "properties": {
                "user_id": {
                  "description": "user slug",
                  "type": "string"
                }
              }
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created"
          }
        }
      }
    },
    "/me": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Shows the authenticated users profile info",
        "produces": [
          "application/json"
        ],
        "tags": [
          "user"
        ],
        "summary": "Get your profile info",
        "operationId": "user-profile",
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.UserProfileRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/me/activities": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all the Bitrise activity events",
        "produces": [
          "application/json"
        ],
        "tags": [
          "activity"
        ],
        "summary": "Get list of Bitrise activity events",
        "operationId": "activity-list",
        "parameters": [
          {
            "type": "string",
            "description": "Slug of the first activity event in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of elements per page (default: 50)",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.ActivityEventListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all Bitrise organizations that the user is part of",
        "produces": [
          "application/json"
        ],
        "tags": [
          "organizations"
        ],
        "summary": "List the organizations that the user is part of",
        "operationId": "org-list",
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.OrganizationListRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations/{org-slug}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Get a specified Bitrise organization that the user is part of.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "organizations"
        ],
        "summary": "Get a specified organization.",
        "operationId": "org-show",
        "parameters": [
          {
            "type": "string",
            "description": "The organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.OrganizationRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations/{org-slug}/apple-api-credentials": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List Apple API credentials for a specific Bitrise Workspace",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "apple-api-credentials"
        ],
        "summary": "List Apple API credentials for a specific organization",
        "operationId": "organizations-list-apple-api-credentials",
        "parameters": [
          {
            "type": "string",
            "description": "Organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.OrganizationAppleAPICredentialsListResponse"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Creates a new Apple API Credential with the given data.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "apple-api-credentials"
        ],
        "summary": "Create Apple API Credential",
        "operationId": "organizations-create-apple-api-credentials",
        "parameters": [
          {
            "type": "string",
            "description": "Organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "The Apple API credential information",
            "name": "types",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.OrganizationAppleAPICredetialCreateParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.OrganizationAppleAPICredetialCreateResponse"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Removes the Apple API Credential with the identifier.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "apple-api-credentials"
        ],
        "summary": "Delete Apple API Credential",
        "operationId": "organizations-delete-apple-api-credentials",
        "parameters": [
          {
            "type": "string",
            "description": "Organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "204": {
            "description": "No Content"
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations/{org-slug}/apps": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all the available apps owned by a given organization. [Find the organization URL](https://devcenter.bitrise.io/team-management/organizations/org-url/) of the organisations you are part of; be aware that the endpoint will not return any apps if the authenticated account is not a member of the given organisation.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Get list of the apps for an organization",
        "operationId": "app-list-by-organization",
        "parameters": [
          {
            "type": "string",
            "description": "Organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          },
          {
            "enum": [
              "last_build_at",
              "created_at"
            ],
            "type": "string",
            "description": "Order of applications: sort them based on when they were created or the time of their last build",
            "name": "sort_by",
            "in": "query"
          },
          {
            "type": "string",
            "description": "Slug of the first app in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of elements per page (default: 50)",
            "name": "limit",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The title of the app",
            "name": "title",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The project type of the app (eg. 'ios', 'android')",
            "name": "project_type",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations/{org-slug}/apps/machine_types": {
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Migrates all apps' machine types of an organization from one machine type to another",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "organizations"
        ],
        "summary": "Migrate machine types",
        "operationId": "organization-machine-type-update",
        "parameters": [
          {
            "type": "string",
            "description": "Organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Machine type to migrate from and to",
            "name": "types",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.OrganizationUpdateMachineTypeParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.OrganizationUpdateMachineTypeResponse"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations/{org-slug}/available-stacks": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List available stacks for the given organization. Returns stacks accessible to the organization, including any custom stacks.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "configuration"
        ],
        "summary": "List available stacks for an organization",
        "operationId": "organization-available-stacks-list",
        "parameters": [
          {
            "type": "string",
            "description": "organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/service.dto.AvailableStacksRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations/{org-slug}/google-service-credentials": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List Google Service credentials for a specific Bitrise Workspace",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "google-service-credentials"
        ],
        "summary": "List Google Service credentials for a specific organization",
        "operationId": "organizations-list-google-service-credentials",
        "parameters": [
          {
            "type": "string",
            "description": "Organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.OrganizationGoogleServiceCredentialsListResponse"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Creates a new Google Service Credential with the given data.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "google-service-credentials"
        ],
        "summary": "Create Google Service Credential",
        "operationId": "organizations-create-google-service-credentials",
        "parameters": [
          {
            "type": "string",
            "description": "Organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "The Google Service credential information",
            "name": "types",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.OrganizationGoogleServiceCredetialCreateParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.OrganizationGoogleServiceCredetialCreateResponse"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Removes the Google Service Credential with the identifier.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "google-service-credentials"
        ],
        "summary": "Delete Google Service Credential",
        "operationId": "organizations-delete-google-service-credentials",
        "parameters": [
          {
            "type": "string",
            "description": "Organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "204": {
            "description": "No Content"
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations/{org-slug}/groups": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Lists the groups of an organization",
        "produces": [
          "application/json"
        ],
        "tags": [
          "organizations"
        ],
        "summary": "List organizations groups",
        "operationId": "organization-group-list",
        "parameters": [
          {
            "type": "string",
            "description": "organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/service.dto.Group"
              }
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Adds a group to the organization",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "organizations"
        ],
        "summary": "Adds a group to the organization",
        "operationId": "organization-group-add",
        "parameters": [
          {
            "type": "string",
            "description": "organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "group data",
            "name": "member",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "properties": {
                "name": {
                  "type": "string"
                }
              }
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "$ref": "#/definitions/service.dto.Group"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations/{org-slug}/members": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List the members of the organization",
        "produces": [
          "application/json"
        ],
        "tags": [
          "organizations"
        ],
        "summary": "List the members of the organization",
        "operationId": "member-list",
        "parameters": [
          {
            "type": "string",
            "description": "organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/service.dto.Member"
              }
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Adds a member to the organization",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "organizations"
        ],
        "summary": "Adds a member to the organization",
        "operationId": "member-add",
        "parameters": [
          {
            "type": "string",
            "description": "organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "member data",
            "name": "member",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "properties": {
                "email": {
                  "type": "string"
                }
              }
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "$ref": "#/definitions/service.dto.Member"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations/{org-slug}/secrets": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Get the secrets of an organization",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "Get the secrets of an organization",
        "operationId": "organization-secrets-list",
        "parameters": [
          {
            "type": "string",
            "description": "organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Ok",
            "schema": {
              "type": "object",
              "properties": {
                "secrets": {
                  "type": "array",
                  "items": {
                    "$ref": "#/definitions/service.dto.CreatedSecretNoValue"
                  }
                }
              }
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Create a new organization secret",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "Create a new organization secret",
        "operationId": "organization-secret-create",
        "parameters": [
          {
            "type": "string",
            "description": "organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "secret data",
            "name": "secret",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "required": [
                "name",
                "value"
              ],
              "properties": {
                "expand_in_step_inputs": {
                  "type": "boolean"
                },
                "is_exposed_for_pull_requests": {
                  "type": "boolean"
                },
                "is_protected": {
                  "type": "boolean"
                },
                "name": {
                  "type": "string"
                },
                "scope": {
                  "type": "string"
                },
                "value": {
                  "type": "string"
                }
              }
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": {
              "$ref": "#/definitions/service.dto.CreatedSecretNoValue"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations/{org-slug}/secrets/{secret-name}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Get a single secret by name, including the value if not protected",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "Get a single secret by name",
        "operationId": "organization-secrets-show",
        "parameters": [
          {
            "type": "string",
            "description": "organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "secret name",
            "name": "secret-name",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Ok",
            "schema": {
              "allOf": [
                {
                  "$ref": "#/definitions/service.dto.CreatedSecretNoValue"
                },
                {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  }
                }
              ]
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "delete": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Delete a secret by name",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "Delete a secret by name",
        "operationId": "organization-secret-delete",
        "parameters": [
          {
            "type": "string",
            "description": "organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "secret name",
            "name": "secret-name",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "204": {
            "description": "No Content"
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      },
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Update an existing secret. If the secret is protected, only its value can be overridden.",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "secrets"
        ],
        "summary": "Update an existing secret",
        "operationId": "organization-secret-update",
        "parameters": [
          {
            "type": "string",
            "description": "organization slug",
            "name": "org-slug",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "secret name",
            "name": "secret-name",
            "in": "path",
            "required": true
          },
          {
            "description": "secret data",
            "name": "secret",
            "in": "body",
            "required": true,
            "schema": {
              "type": "object",
              "properties": {
                "expand_in_step_inputs": {
                  "type": "boolean"
                },
                "is_exposed_for_pull_requests": {
                  "type": "boolean"
                },
                "is_protected": {
                  "type": "boolean"
                },
                "value": {
                  "type": "string"
                }
              }
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Ok",
            "schema": {
              "allOf": [
                {
                  "$ref": "#/definitions/service.dto.CreatedSecretNoValue"
                },
                {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  }
                }
              ]
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "403": {
            "description": "Forbidden",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          },
          "404": {
            "description": "Not found",
            "schema": {
              "$ref": "#/definitions/service.ProxyErrorRespModel"
            }
          }
        }
      }
    },
    "/organizations/{organization-slug}/addons": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all the provisioned addons for organization",
        "produces": [
          "application/json"
        ],
        "tags": [
          "addons"
        ],
        "summary": "Get list of the addons for organization",
        "operationId": "addon-list-by-organization",
        "parameters": [
          {
            "type": "string",
            "description": "Organization slug",
            "name": "organization-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.OwnerAddOnsListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/pipelines": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all the Bitrise pipelines/standalone builds that can be accessed with the authenticated account. Filter pipelines/standalone builds based on their owner, using the owner slug, or the status of the pipeline/standalone build.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "pipelines"
        ],
        "summary": "List all pipelines/standalone builds",
        "operationId": "pipeline-list-all",
        "parameters": [
          {
            "type": "string",
            "description": "The slug of the owner of the app or apps",
            "name": "owner_slug",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The status of the pipelines/standalone build: on_hold, running, succeeded, failed, aborted, succeeded_with_abort",
            "name": "status",
            "in": "query"
          },
          {
            "type": "string",
            "description": "Getting pipelines/standalone builds before the given parameter (RFC3339 time format)",
            "name": "next",
            "in": "query"
          },
          {
            "type": "integer",
            "description": "Max number of elements per page (default: 10)",
            "name": "limit",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.PipelineListAllResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/search-steps": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Find steps for building workflows or step bundles in a Bitrise YML config file, based on name, description, tags or maintainers.Returns only the latest, non-deprecated versions.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "configuration"
        ],
        "summary": "Find steps",
        "operationId": "search-steps",
        "parameters": [
          {
            "type": "string",
            "description": "The phrase to search steps for",
            "name": "query",
            "in": "query",
            "required": true
          },
          {
            "type": "array",
            "items": {
              "enum": [
                "build",
                "code-sign",
                "test",
                "deploy",
                "notification",
                "access-control",
                "artifact-info",
                "installer",
                "dependency",
                "utility"
              ],
              "type": "string"
            },
            "description": "Categories to filter steps.",
            "name": "categories",
            "in": "query"
          },
          {
            "type": "array",
            "items": {
              "enum": [
                "bitrise",
                "verified",
                "community"
              ],
              "type": "string"
            },
            "description": "Filter steps by maintainers. Use `bitrise` to only look for official steps.",
            "name": "maintainers",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "Step data returned",
            "schema": {
              "$ref": "#/definitions/service.dto.StepSearchRespModel"
            }
          },
          "400": {
            "description": "Missing or invalid parameters",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/step-inputs": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List inputs of a step with their defaults, allowed values etc.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "configuration"
        ],
        "summary": "List step inputs",
        "operationId": "step-inputs",
        "parameters": [
          {
            "type": "string",
            "description": "Step reference formatted as `step_lib_source::step_id@version`. `step_id` and an exact `version` are required, `step_lib_source` is only necessary for custom step sources.",
            "name": "step_ref",
            "in": "query",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Step inputs returned",
            "schema": {
              "$ref": "#/definitions/service.dto.StepInputsRespModel"
            }
          },
          "400": {
            "description": "Missing or invalid parameters",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/user/{user-slug}/apps/machine_types": {
      "patch": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Migrates all apps' machine types of a user from one machine type to another",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "user"
        ],
        "summary": "Migrate machine types",
        "operationId": "user-machine-type-update",
        "parameters": [
          {
            "type": "string",
            "description": "User slug",
            "name": "user-slug",
            "in": "path",
            "required": true
          },
          {
            "description": "Machine type to migrate from and to",
            "name": "types",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/v0.OrganizationUpdateMachineTypeParams"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.OrganizationUpdateMachineTypeResponse"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/users/{user-slug}": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Show information about a specific user",
        "produces": [
          "application/json"
        ],
        "tags": [
          "user"
        ],
        "summary": "Get a specific user",
        "operationId": "user-show",
        "parameters": [
          {
            "type": "string",
            "description": "User slug",
            "name": "user-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.UserProfileRespModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/users/{user-slug}/addons": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all the provisioned addons for the authenticated user",
        "produces": [
          "application/json"
        ],
        "tags": [
          "addons"
        ],
        "summary": "Get list of the addons for user",
        "operationId": "addon-list-by-user",
        "parameters": [
          {
            "type": "string",
            "description": "User slug",
            "name": "user-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.OwnerAddOnsListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/users/{user-slug}/apple-api-credentials": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List Apple API credentials for a specific Bitrise user",
        "produces": [
          "application/json"
        ],
        "tags": [
          "apple-api-credentials"
        ],
        "summary": "List Apple API credentials for a specific user",
        "operationId": "apple-api-credential-list",
        "parameters": [
          {
            "type": "string",
            "description": "User slug",
            "name": "user-slug",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppleAPICredentialsListResponse"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/users/{user-slug}/apps": {
      "get": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "List all the available apps for the given user.  It needs the user slug that you can get from the [GET /me](https://api-docs.bitrise.io/#/user/user-profile) endpoint.",
        "produces": [
          "application/json"
        ],
        "tags": [
          "application"
        ],
        "summary": "Get list of the apps for a user",
        "operationId": "app-list-by-user",
        "parameters": [
          {
            "type": "string",
            "description": "User slug",
            "name": "user-slug",
            "in": "path",
            "required": true
          },
          {
            "enum": [
              "last_build_at",
              "created_at"
            ],
            "type": "string",
            "description": "Order of applications",
            "name": "sort_by",
            "in": "query"
          },
          {
            "type": "string",
            "description": "Slug of the first app in the response",
            "name": "next",
            "in": "query"
          },
          {
            "maximum": 50,
            "type": "integer",
            "description": "Max number of elements per page (default: 50)",
            "name": "limit",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The title of the app",
            "name": "title",
            "in": "query"
          },
          {
            "type": "string",
            "description": "The project type of the app (eg. 'ios', 'android')",
            "name": "project_type",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "schema": {
              "$ref": "#/definitions/v0.AppListResponseModel"
            }
          },
          "400": {
            "description": "Bad Request",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "401": {
            "description": "Unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "Not Found",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "500": {
            "description": "Internal Server Error",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    },
    "/validate-bitrise-yml": {
      "post": {
        "security": [
          {
            "PersonalAccessToken": []
          }
        ],
        "description": "Validate a Bitrise YAML file",
        "consumes": [
          "application/yaml",
          "application/json",
          "text/plain"
        ],
        "produces": [
          "application/json"
        ],
        "tags": [
          "configuration"
        ],
        "summary": "Validate a Bitrise YAML file",
        "operationId": "validate-bitrise-yml",
        "parameters": [
          {
            "type": "string",
            "description": "App slug to validate against app specific settings (stack, machines, licenses etc.)",
            "name": "app_slug",
            "in": "query"
          },
          {
            "description": "Bitrise YAML content (as string for YAML or plain text content type, or object with bitrise_yml property for JSON)",
            "name": "bitrise_yml",
            "in": "body",
            "schema": {
              "type": "object",
              "required": [
                "bitrise_yml"
              ],
              "properties": {
                "bitrise_yml": {
                  "type": "string"
                }
              }
            }
          }
        ],
        "responses": {
          "200": {
            "description": "YML is valid",
            "schema": {
              "$ref": "#/definitions/service.dto.ValidateBitriseYMLRespModel"
            }
          },
          "400": {
            "description": "Missing or invalid parameters",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "404": {
            "description": "App not found or unauthorized",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "413": {
            "description": "Payload too large (\u003e400KB)",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          },
          "422": {
            "description": "Validation failed",
            "schema": {
              "$ref": "#/definitions/service.StandardErrorRespModel"
            }
          }
        }
      }
    }
  },
  "definitions": {
    "addons.Addon": {
      "type": "object",
      "properties": {
        "banner_image": {
          "type": "string"
        },
        "card_header_colors": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "categories": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "description": {
          "type": "string"
        },
        "developer_links": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/addons.DeveloperLink"
          }
        },
        "documentation_url": {
          "type": "string"
        },
        "has_ui": {
          "type": "boolean"
        },
        "icon": {
          "type": "string"
        },
        "id": {
          "type": "string"
        },
        "is_beta": {
          "type": "boolean"
        },
        "plans": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/addons.Plan"
          }
        },
        "platforms": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "preview_images": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "setup_guide": {
          "$ref": "#/definitions/addons.SetupGuide"
        },
        "subtitle": {
          "type": "string"
        },
        "summary": {
          "type": "string"
        },
        "title": {
          "type": "string"
        }
      }
    },
    "addons.DeveloperLink": {
      "type": "object",
      "properties": {
        "title": {
          "type": "string"
        },
        "url": {
          "type": "string"
        }
      }
    },
    "addons.Feature": {
      "type": "object",
      "properties": {
        "available": {
          "type": "boolean"
        },
        "description": {
          "type": "string"
        },
        "quantity": {
          "type": "string"
        }
      }
    },
    "addons.Plan": {
      "type": "object",
      "properties": {
        "features": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/addons.Feature"
          }
        },
        "id": {
          "type": "string"
        },
        "name": {
          "type": "string"
        },
        "price": {
          "type": "integer"
        }
      }
    },
    "addons.SetupGuide": {
      "type": "object",
      "properties": {
        "instructions": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/addons.SetupInstruction"
          }
        },
        "notification": {
          "type": "string"
        }
      }
    },
    "addons.SetupInstruction": {
      "type": "object",
      "properties": {
        "card_content": {
          "type": "string"
        },
        "description": {
          "type": "string"
        },
        "type": {
          "type": "string"
        }
      }
    },
    "pipelineabledomain.ArtifactMeta": {
      "type": "object",
      "properties": {
        "artifact_type": {
          "type": "string"
        },
        "id": {
          "type": "string"
        },
        "title": {
          "type": "string"
        },
        "version_code": {
          "type": "string"
        },
        "version_name": {
          "type": "string"
        }
      }
    },
    "pipelineabledomain.BuildToolInvocation": {
      "type": "object",
      "properties": {
        "invocation_id": {
          "type": "string"
        },
        "tool": {
          "type": "string"
        },
        "tool_version": {
          "type": "string"
        }
      }
    },
    "pipelineabledomain.CommitPaths": {
      "type": "object",
      "properties": {
        "added": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "modified": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "removed": {
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "pipelineabledomain.Environments": {
      "type": "object",
      "properties": {
        "is_expand": {},
        "key": {
          "type": "string"
        },
        "value": {}
      }
    },
    "pipelineabledomain.LocalConfig": {
      "type": "object",
      "properties": {
        "host": {
          "type": "string"
        },
        "username": {
          "type": "string"
        }
      }
    },
    "pipelineabledomain.TriggerParams": {
      "type": "object",
      "properties": {
        "base_repository_url": {
          "type": "string"
        },
        "branch": {
          "type": "string"
        },
        "branch_dest": {
          "type": "string"
        },
        "branch_dest_repo_owner": {
          "type": "string"
        },
        "branch_repo_owner": {
          "type": "string"
        },
        "commit_hash": {
          "type": "string"
        },
        "commit_message": {
          "type": "string"
        },
        "commit_messages": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "commit_paths": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/pipelineabledomain.CommitPaths"
          }
        },
        "environments": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/pipelineabledomain.Environments"
          }
        },
        "head_repository_url": {
          "type": "string"
        },
        "machine_type_id": {
          "type": "string"
        },
        "priority": {
          "type": "integer"
        },
        "pull_request_author": {
          "type": "string"
        },
        "pull_request_comment": {
          "type": "string"
        },
        "pull_request_comment_id": {
          "type": "string"
        },
        "pull_request_head_branch": {
          "type": "string"
        },
        "pull_request_id": {},
        "pull_request_labels": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "pull_request_labels_added": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "pull_request_merge_branch": {
          "type": "string"
        },
        "pull_request_ready_state": {
          "type": "string"
        },
        "pull_request_repository_url": {
          "type": "string"
        },
        "pull_request_unverified_merge_branch": {
          "type": "string"
        },
        "skip_git_status_report": {
          "type": "boolean"
        },
        "stack": {
          "type": "string"
        },
        "tag": {}
      }
    },
    "service.ProxyErrorRespModel": {
      "type": "object",
      "properties": {
        "error_msg": {
          "type": "string"
        }
      }
    },
    "service.StandardErrorRespModel": {
      "type": "object",
      "properties": {
        "message": {
          "type": "string"
        }
      }
    },
    "service.dto.AvailableStacksRespModel": {
      "description": "A map of stack IDs to stack information",
      "type": "object",
      "additionalProperties": {
        "$ref": "#/definitions/service.dto.StackInfo"
      }
    },
    "service.dto.BuildLogSummaryCLIInfo": {
      "type": "object",
      "properties": {
        "bitrise_cli_version": {
          "type": "string"
        },
        "ci_mode": {
          "type": "boolean"
        },
        "debug_mode": {
          "type": "boolean"
        },
        "log_format_version": {
          "type": "string"
        },
        "no_output_timeout_mode": {
          "type": "boolean"
        },
        "pr_mode": {
          "type": "boolean"
        },
        "secret_envs_filtering_mode": {
          "type": "boolean"
        },
        "secret_filtering_mode": {
          "type": "boolean"
        }
      }
    },
    "service.dto.BuildLogSummaryContainer": {
      "type": "object",
      "properties": {
        "image": {
          "type": "string"
        }
      }
    },
    "service.dto.BuildLogSummaryExecution": {
      "type": "object",
      "properties": {
        "build_environment_setup": {
          "type": "object",
          "properties": {
            "finished_at": {
              "type": "string",
              "format": "date-time"
            },
            "started_at": {
              "type": "string",
              "format": "date-time"
            },
            "status": {
              "type": "string"
            }
          }
        },
        "step_bundles": {
          "description": "Step bundles, keyed by the `step_bundle_uuid` of their steps",
          "type": "object",
          "additionalProperties": {
            "type": "object",
            "properties": {
              "id": {
                "type": "string"
              },
              "title": {
                "type": "string"
              }
            }
          }
        },
        "with_groups": {
          "description": "Step groups that run in a container, keyed by the `with_group_uuid` of their steps",
          "type": "object",
          "additionalProperties": {
            "type": "object",
            "properties": {
              "container": {
                "$ref": "#/definitions/service.dto.BuildLogSummaryContainer"
              },
              "services": {
                "type": "array",
                "items": {
                  "$ref": "#/definitions/service.dto.BuildLogSummaryContainer"
                }
              }
            }
          }
        },
        "workflows": {
          "description": "Workflows in execution order, including before_run and after_run workflows",
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.BuildLogSummaryWorkflow"
          }
        }
      }
    },
    "service.dto.BuildLogSummaryRespModel": {
      "type": "object",
      "properties": {
        "agent_info": {
          "description": "Information about the build machine",
          "type": "object",
          "additionalProperties": true
        },
        "cli_info": {
          "$ref": "#/definitions/service.dto.BuildLogSummaryCLIInfo"
        },
        "execution": {
          "$ref": "#/definitions/service.dto.BuildLogSummaryExecution"
        },
        "has_build_environment_setup_logs": {
          "type": "boolean"
        },
        "is_log_archived": {
          "type": "boolean"
        }
      }
    },
    "service.dto.BuildLogSummaryStep": {
      "type": "object",
      "properties": {
        "collection": {
          "type": "string"
        },
        "deprecation_notice": {
          "type": "string"
        },
        "errors": {
          "description": "Why the step failed or was aborted, including the exit code or timeout. Only set for `failed`, `failed_skippable`, `preparation_failed` and `aborted_with_*` steps.",
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.BuildLogSummaryStepError"
          }
        },
        "finished_at": {
          "type": "string",
          "format": "date-time"
        },
        "latest_version": {
          "type": "string"
        },
        "release_notes": {
          "type": "string"
        },
        "source_code_url": {
          "type": "string"
        },
        "started_at": {
          "type": "string",
          "format": "date-time"
        },
        "status": {
          "type": "string",
          "enum": [
            "not_started",
            "started",
            "success",
            "failed",
            "failed_skippable",
            "preparation_failed",
            "skipped",
            "skipped_with_run_if",
            "aborted",
            "aborted_with_custom_timeout",
            "aborted_with_no_output"
          ]
        },
        "status_reason": {
          "description": "Why the step was skipped, or why its failure did not fail the build. Only set for `skipped`, `skipped_with_run_if` and `failed_skippable` steps.",
          "type": "string"
        },
        "step_bundle_uuid": {
          "type": "string"
        },
        "step_id": {
          "type": "string"
        },
        "support_url": {
          "type": "string"
        },
        "title": {
          "type": "string"
        },
        "uuid": {
          "description": "Use it to fetch the log of this step",
          "type": "string"
        },
        "version": {
          "type": "string"
        },
        "with_group_uuid": {
          "type": "string"
        }
      }
    },
    "service.dto.BuildLogSummaryStepError": {
      "type": "object",
      "properties": {
        "code": {
          "type": "integer"
        },
        "message": {
          "type": "string"
        }
      }
    },
    "service.dto.BuildLogSummaryWorkflow": {
      "type": "object",
      "properties": {
        "steps": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.BuildLogSummaryStep"
          }
        },
        "uuid": {
          "type": "string"
        },
        "workflow_id": {
          "type": "string"
        }
      }
    },
    "service.dto.BuildTestResultsRespModel": {
      "type": "object",
      "properties": {
        "test_suites": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.TestSuite"
          }
        }
      }
    },
    "service.dto.CreatedSecretNoValue": {
      "type": "object",
      "properties": {
        "expand_in_step_inputs": {
          "type": "boolean"
        },
        "id": {
          "type": "string"
        },
        "is_exposed_for_pull_requests": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "name": {
          "type": "string"
        },
        "scope": {
          "type": "string"
        }
      }
    },
    "service.dto.Group": {
      "type": "object",
      "properties": {
        "name": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        }
      }
    },
    "service.dto.Member": {
      "type": "object",
      "properties": {
        "email": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "username": {
          "type": "string"
        }
      }
    },
    "service.dto.QuarantinedTest": {
      "type": "object",
      "properties": {
        "class_name": {
          "type": "string"
        },
        "comment": {
          "type": "string"
        },
        "filters": {
          "$ref": "#/definitions/service.dto.QuarantinedTestFilters"
        },
        "id": {
          "description": "ID of the quarantined test",
          "type": "string"
        },
        "quarantined_at": {
          "type": "string",
          "format": "date-time"
        },
        "quarantined_by": {
          "description": "Username of the user who quarantined the test",
          "type": "string"
        },
        "quarantined_from": {
          "$ref": "#/definitions/service.dto.QuarantinedTestSource"
        },
        "test_case_identifier": {
          "description": "Identifier of the test case, when the test report provides one",
          "type": "string"
        },
        "test_case_name": {
          "type": "string"
        },
        "test_suite_name": {
          "description": "Names of the test suites containing the test case, outermost first",
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "service.dto.QuarantinedTestFilters": {
      "description": "Limits the quarantine to builds on matching branches and of matching Workflows or Pipelines. Values may contain `*` wildcards. An empty or null list matches everything.",
      "type": "object",
      "properties": {
        "branches": {
          "type": "array",
          "items": {
            "type": "string"
          },
          "x-nullable": true
        },
        "targets": {
          "description": "Workflow or Pipeline names",
          "type": "array",
          "items": {
            "type": "string"
          },
          "x-nullable": true
        }
      }
    },
    "service.dto.QuarantinedTestSource": {
      "description": "Where the test was quarantined from",
      "type": "object",
      "properties": {
        "number": {
          "description": "Number of the build or pipeline the test was quarantined from",
          "type": "integer"
        },
        "slug": {
          "description": "Slug of the build or pipeline the test was quarantined from",
          "type": "string"
        },
        "source": {
          "type": "string",
          "enum": [
            "api",
            "build",
            "insights",
            "pipeline"
          ]
        }
      }
    },
    "service.dto.QuarantinedTestsRespModel": {
      "type": "object",
      "properties": {
        "quarantined_tests": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.QuarantinedTest"
          }
        }
      }
    },
    "service.dto.StackInfo": {
      "type": "object",
      "properties": {
        "description": {
          "description": "Description of the stack",
          "type": "string"
        },
        "id": {
          "description": "Unique identifier for the stack",
          "type": "string"
        },
        "os": {
          "description": "Operating system of the stack",
          "type": "string",
          "enum": [
            "linux",
            "macos"
          ]
        },
        "os_version": {
          "description": "OS version number",
          "type": "integer"
        },
        "removal-date": {
          "description": "The date on which the stack will no longer be available. This field is typically only set for frozen stacks. ISO 8601 (YYYY-MM-DD) format.",
          "type": "string"
        },
        "stack-report": {
          "description": "URL to the stack report with pre-installed tools information",
          "type": "string"
        },
        "status": {
          "description": "Current status of the stack. Note: this changes over the lifetime of a stack, see Stack update policy for details.",
          "type": "string",
          "enum": [
            "stable",
            "edge",
            "frozen"
          ]
        },
        "title": {
          "description": "Human-readable title of the stack",
          "type": "string"
        }
      }
    },
    "service.dto.StepInputOutputResponse": {
      "type": "object",
      "properties": {
        "default_value": {
          "type": "string"
        },
        "description": {
          "type": "string"
        },
        "is_required": {
          "type": "boolean"
        },
        "is_sensitive": {
          "type": "boolean"
        },
        "name": {
          "type": "string"
        },
        "summary": {
          "type": "string"
        },
        "title": {
          "type": "string"
        },
        "value_options": {
          "description": "List of allowed values for the parameter (if restricted)",
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "service.dto.StepInputsRespModel": {
      "type": "array",
      "items": {
        "$ref": "#/definitions/service.dto.StepInputOutputResponse"
      }
    },
    "service.dto.StepResponse": {
      "type": "object",
      "properties": {
        "description": {
          "type": "string"
        },
        "id": {
          "description": "Unique identifier for the step",
          "type": "string"
        },
        "inputs": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.StepInputOutputResponse"
          }
        },
        "is_deprecated": {
          "type": "boolean"
        },
        "is_latest": {
          "type": "boolean"
        },
        "latest_version_number": {
          "type": "string"
        },
        "maintainer": {
          "description": "Maintainer of the step",
          "type": "string",
          "enum": [
            "bitrise",
            "verified",
            "community"
          ]
        },
        "outputs": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.StepInputOutputResponse"
          }
        },
        "step_ref": {
          "description": "Composite Version Specification of the step, see https://docs.bitrise.io/en/bitrise-ci/references/steps-reference/step-reference-id-format.html",
          "type": "string"
        },
        "summary": {
          "type": "string"
        },
        "title": {
          "type": "string"
        },
        "version": {
          "description": "Version number of the step",
          "type": "string"
        }
      }
    },
    "service.dto.StepSearchRespModel": {
      "type": "array",
      "items": {
        "$ref": "#/definitions/service.dto.StepResponse"
      }
    },
    "service.dto.TestAttachment": {
      "type": "object",
      "properties": {
        "url": {
          "type": "string"
        }
      }
    },
    "service.dto.TestCase": {
      "type": "object",
      "properties": {
        "attachments": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.TestAttachment"
          }
        },
        "class_name": {
          "type": "string"
        },
        "duration_in_ms": {
          "type": "integer"
        },
        "flaky": {
          "description": "Whether the test case is flaky",
          "type": "boolean"
        },
        "message": {
          "description": "Failure or error message of the test case",
          "type": "string"
        },
        "name": {
          "type": "string"
        },
        "properties": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.TestProperty"
          }
        },
        "runs": {
          "description": "Individual runs of the test case when it was retried",
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.TestRun"
          }
        },
        "status": {
          "type": "string",
          "enum": [
            "passed",
            "failed",
            "skipped",
            "error"
          ]
        },
        "test_suites": {
          "description": "Names of the test suites the test case originally belonged to",
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "service.dto.TestProperty": {
      "type": "object",
      "properties": {
        "key": {
          "type": "string"
        },
        "value": {
          "type": "string"
        }
      }
    },
    "service.dto.TestRun": {
      "type": "object",
      "properties": {
        "attachments": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.TestAttachment"
          }
        },
        "duration_in_ms": {
          "type": "integer"
        },
        "message": {
          "type": "string"
        },
        "name": {
          "type": "string"
        },
        "status": {
          "type": "string",
          "enum": [
            "passed",
            "failed",
            "skipped",
            "error"
          ]
        }
      }
    },
    "service.dto.TestSuite": {
      "type": "object",
      "properties": {
        "attachments": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.TestAttachment"
          }
        },
        "duration_in_ms": {
          "type": "integer"
        },
        "error_count": {
          "type": "integer"
        },
        "failure_count": {
          "type": "integer"
        },
        "name": {
          "type": "string"
        },
        "properties": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.TestProperty"
          }
        },
        "skipped_count": {
          "type": "integer"
        },
        "test_cases": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.TestCase"
          }
        },
        "test_count": {
          "type": "integer"
        },
        "test_suites": {
          "description": "Nested test suites",
          "type": "array",
          "items": {
            "$ref": "#/definitions/service.dto.TestSuite"
          }
        }
      }
    },
    "service.dto.ValidateBitriseYMLRespModel": {
      "type": "object",
      "properties": {
        "errors": {
          "description": "Validation errors",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "warnings": {
          "description": "Validation warnings",
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "v0.ActivityEventListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.ActivityEventResponseItemModel"
          }
        },
        "paging": {
          "$ref": "#/definitions/v0.PagingResponseModel"
        }
      }
    },
    "v0.ActivityEventResponseItemModel": {
      "type": "object",
      "properties": {
        "created_at": {
          "type": "string"
        },
        "description": {
          "type": "string"
        },
        "event_icon": {
          "type": "string"
        },
        "event_stype": {
          "type": "string"
        },
        "repository_avatar_icon_url": {
          "type": "string"
        },
        "repository_title": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "target_path_string": {
          "type": "string"
        },
        "title": {
          "type": "string"
        }
      }
    },
    "v0.AddOnAppResponseItemModel": {
      "type": "object",
      "properties": {
        "icon": {
          "type": "string"
        },
        "plan": {
          "$ref": "#/definitions/addons.Plan"
        },
        "plan_started_at": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "title": {
          "type": "string"
        }
      }
    },
    "v0.AddonsListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/addons.Addon"
          }
        }
      }
    },
    "v0.AddonsShowResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/addons.Addon"
        }
      }
    },
    "v0.AndroidKeystoreFileDownloadResponseItemModel": {
      "type": "object",
      "properties": {
        "certificate_sha256_fingerprint": {
          "description": "Read-only. SHA-256 fingerprint of the signing certificate inside the keystore, rendered as uppercase hexadecimal with colon separators (keytool format). Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "ED:FB:D3:78:E6:38:F6:53:17:0C:9C:93:E8:7C:6E:AF:98:4A:4D:1A:22:CA:7E:DF:FF:51:3D:20:CC:A3:68:D3"
        },
        "download_url": {
          "type": "string"
        },
        "exposed_meta_datastore": {
          "type": "object"
        },
        "file_sha256": {
          "description": "Read-only. SHA-256 hash of the uploaded file bytes, rendered as lowercase hexadecimal. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        },
        "user_env_key": {
          "type": "string"
        }
      }
    },
    "v0.AndroidKeystoreFileDownloadResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.AndroidKeystoreFileDownloadResponseItemModel"
        }
      }
    },
    "v0.AndroidKeystoreFileListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.AndroidKeystoreFileResponseItemModel"
          }
        },
        "paging": {
          "description": "pagination",
          "allOf": [
            {
              "$ref": "#/definitions/v0.PagingResponseModel"
            }
          ]
        }
      }
    },
    "v0.AndroidKeystoreFileResponseItemModel": {
      "type": "object",
      "properties": {
        "certificate_sha256_fingerprint": {
          "description": "Read-only. SHA-256 fingerprint of the signing certificate inside the keystore, rendered as uppercase hexadecimal with colon separators (keytool format). Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "ED:FB:D3:78:E6:38:F6:53:17:0C:9C:93:E8:7C:6E:AF:98:4A:4D:1A:22:CA:7E:DF:FF:51:3D:20:CC:A3:68:D3"
        },
        "exposed_meta_datastore": {
          "type": "object"
        },
        "file_sha256": {
          "description": "Read-only. SHA-256 hash of the uploaded file bytes, rendered as lowercase hexadecimal. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        },
        "user_env_key": {
          "type": "string"
        }
      }
    },
    "v0.AndroidKeystoreFileResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.AndroidKeystoreFileResponseItemModel"
        }
      }
    },
    "v0.AndroidKeystoreFileUploadParams": {
      "type": "object",
      "required": [
        "alias",
        "password",
        "private_key_password",
        "upload_file_name",
        "upload_file_size"
      ],
      "properties": {
        "alias": {
          "type": "string"
        },
        "keystore_file_name": {
          "type": "string"
        },
        "password": {
          "type": "string"
        },
        "private_key_password": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        }
      }
    },
    "v0.AndroidKeystoreFileUploadResponseItemModel": {
      "type": "object",
      "properties": {
        "certificate_sha256_fingerprint": {
          "description": "Read-only. SHA-256 fingerprint of the signing certificate inside the keystore, rendered as uppercase hexadecimal with colon separators (keytool format). Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "ED:FB:D3:78:E6:38:F6:53:17:0C:9C:93:E8:7C:6E:AF:98:4A:4D:1A:22:CA:7E:DF:FF:51:3D:20:CC:A3:68:D3"
        },
        "exposed_meta_datastore": {
          "type": "object"
        },
        "file_sha256": {
          "description": "Read-only. SHA-256 hash of the uploaded file bytes, rendered as lowercase hexadecimal. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        },
        "upload_url": {
          "type": "string"
        },
        "user_env_key": {
          "type": "string"
        }
      }
    },
    "v0.AndroidKeystoreFileUploadResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.AndroidKeystoreFileUploadResponseItemModel"
        }
      }
    },
    "v0.AppAddOnResponseItemModel": {
      "type": "object",
      "properties": {
        "description": {
          "type": "string"
        },
        "documentation_url": {
          "type": "string"
        },
        "has_ui": {
          "type": "boolean"
        },
        "icon": {
          "type": "string"
        },
        "id": {
          "type": "string"
        },
        "is_beta": {
          "type": "boolean"
        },
        "is_enabled": {
          "type": "boolean"
        },
        "login_url": {
          "type": "string"
        },
        "plan": {
          "$ref": "#/definitions/addons.Plan"
        },
        "scopes": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "setup_guide": {
          "$ref": "#/definitions/addons.SetupGuide"
        },
        "summary": {
          "type": "string"
        },
        "terms_url": {
          "type": "string"
        },
        "title": {
          "type": "string"
        }
      }
    },
    "v0.AppAddOnsListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.AppAddOnResponseItemModel"
          }
        }
      }
    },
    "v0.AppConfigRequestParam": {
      "type": "object",
      "required": [
        "app_config_datastore_yaml"
      ],
      "properties": {
        "app_config_datastore_yaml": {
          "description": "The bitrise.yml of your application, defined in JSON format",
          "type": "object"
        }
      }
    },
    "v0.AppConfigRespModel": {
      "type": "object",
      "additionalProperties": {
        "type": "string"
      }
    },
    "v0.AppDeleteRespModel": {
      "type": "object",
      "properties": {
        "msg": {
          "type": "string"
        }
      }
    },
    "v0.AppFinishParams": {
      "type": "object",
      "required": [
        "project_type",
        "stack_id"
      ],
      "properties": {
        "config": {
          "description": "Which config to use. Specify a config that matches your project type (e. g. `default-android-config` for `android`, etc.). If not speficied, default value is `other-config`. The available values are `default-android-config`, `default-cordova-config`, `default-fastlane-android-config`, `default-fastlane-ios-config`, `flutter-config-test-android-2`, `flutter-config-test-both-0`, `flutter-config-test-ios-1`, `default-ionic-config`, `default-ios-config`, `default-macos-config`, `default-react-native-config`, `default-react-native-expo-config`, `other-config`.",
          "type": "string"
        },
        "envs": {
          "description": "Environment variables for the application workflows, e.g. {\"env1\":\"val1\",\"env2\":\"val2\"}",
          "type": "object",
          "additionalProperties": {
            "type": "string"
          }
        },
        "mode": {
          "description": "config specification mode, has to be specified with `manual` value",
          "type": "string"
        },
        "organization_slug": {
          "description": "The slug of the organization, who will be the owner of the application, if it's not specified, then the authenticated user will be the owner",
          "type": "string"
        },
        "project_type": {
          "description": "The type of your project (`android`, `ios`, `cordova`, `other`, `xamarin`, `macos`, `ionic`, `react-native`, `fastlane`, `flutter`, null)",
          "type": "string"
        },
        "stack_id": {
          "description": "The id of the stack the application will be built (these can be found in the [system report](https://github.com/bitrise-io/bitrise.io/tree/master/system_reports) file names)",
          "type": "string"
        }
      }
    },
    "v0.AppFinishRespModel": {
      "type": "object",
      "properties": {
        "branch_name": {
          "type": "string"
        },
        "build_trigger_token": {
          "type": "string"
        },
        "is_webhook_auto_reg_supported": {
          "type": "boolean"
        },
        "status": {
          "type": "string"
        }
      }
    },
    "v0.AppListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.AppResponseItemModel"
          }
        },
        "paging": {
          "description": "pagination",
          "allOf": [
            {
              "$ref": "#/definitions/v0.PagingResponseModel"
            }
          ]
        }
      }
    },
    "v0.AppNotificationSettingsParams": {
      "type": "object",
      "properties": {
        "on_failure": {
          "description": "When should Bitrise send notifications for the users on build failure? Possible values: always, never, change",
          "type": "string"
        },
        "on_success": {
          "description": "When should Bitrise send notifications for the users on build success? Possible values: always, never, change",
          "type": "string"
        }
      }
    },
    "v0.AppNotificationSettingsUpdateResponse": {
      "type": "object",
      "properties": {
        "msg": {
          "type": "string"
        }
      }
    },
    "v0.AppRespModel": {
      "type": "object",
      "properties": {
        "slug": {
          "type": "string"
        },
        "status": {
          "type": "string"
        }
      }
    },
    "v0.AppResponseItemModel": {
      "type": "object",
      "properties": {
        "avatar_url": {
          "type": "string"
        },
        "is_disabled": {
          "type": "boolean"
        },
        "is_github_checks_enabled": {
          "type": "boolean"
        },
        "is_public": {
          "type": "boolean"
        },
        "owner": {
          "$ref": "#/definitions/v0.OwnerAccountResponseModel"
        },
        "project_id": {
          "type": "string"
        },
        "project_type": {
          "type": "string"
        },
        "provider": {
          "type": "string"
        },
        "repo_owner": {
          "type": "string"
        },
        "repo_slug": {
          "type": "string"
        },
        "repo_url": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "status": {
          "type": "integer"
        },
        "title": {
          "type": "string"
        }
      }
    },
    "v0.AppShowResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.AppResponseItemModel"
        }
      }
    },
    "v0.AppUpdateParams": {
      "type": "object",
      "properties": {
        "apple_api_credential_slug": {
          "description": "The new Apple API key's slug (recommendation: use the UI to set this)",
          "type": "string"
        },
        "apple_credential_user_id": {
          "description": "The new apple credential user ID (recommendation: use the UI to set this)",
          "type": "integer"
        },
        "apple_credential_user_slug": {
          "description": "The new apple credential user slug (recommendation: use the UI to set this)",
          "type": "string"
        },
        "default_branch": {
          "description": "The new default branch for the application.",
          "type": "string"
        },
        "is_public": {
          "description": "The new value of whether an application should be publicly visible",
          "type": "boolean"
        },
        "repository_url": {
          "description": "The new repository URL for the application.",
          "type": "string"
        },
        "services_credential_user_id": {
          "description": "The new service credential user ID (recommendation: use the UI to set this)",
          "type": "integer"
        },
        "title": {
          "description": "The new title of the application.",
          "type": "string"
        }
      }
    },
    "v0.AppUpdateRespModel": {
      "type": "object",
      "properties": {
        "status": {
          "type": "string"
        }
      }
    },
    "v0.AppUploadParams": {
      "type": "object",
      "required": [
        "is_public",
        "repo_url"
      ],
      "properties": {
        "default_branch_name": {
          "description": "The default branch of the repository. If it's not specified, it will be `master`.",
          "type": "string"
        },
        "git_owner": {
          "description": "[Deprecated] You no longer need to provide this field.",
          "type": "string"
        },
        "git_repo_slug": {
          "description": "[Deprecated] You no longer need to provide this field.",
          "type": "string"
        },
        "is_public": {
          "description": "If `true` then the repository visibility setting will be public, in case of `false` it will be private",
          "type": "boolean"
        },
        "manual_approval_enabled": {
          "description": "Toggles whether manual approval should be enabled for the app's builds. If it's not specified, it will be `true`.",
          "type": "boolean"
        },
        "organization_slug": {
          "description": "The slug of the organization, who will be the owner of the application. If it's not specified, then the authenticated user will be the owner.",
          "type": "string"
        },
        "provider": {
          "description": "The git provider you are using, it can be `github`, `bitbucket`, `gitlab`, `gitlab-self-hosted` or `custom`",
          "type": "string"
        },
        "repo_url": {
          "description": "The URL of your repository",
          "type": "string"
        },
        "title": {
          "description": "The title of the application. If it's not specified, it will be the git repository's name.",
          "type": "string"
        },
        "type": {
          "description": "[Deprecated] You no longer need to provide this field.",
          "type": "string"
        }
      }
    },
    "v0.AppWebhookCreateParams": {
      "type": "object",
      "required": [
        "events",
        "secret",
        "url"
      ],
      "properties": {
        "events": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "headers": {
          "type": "object"
        },
        "secret": {
          "type": "string"
        },
        "url": {
          "type": "string"
        }
      }
    },
    "v0.AppWebhookCreatedResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.AppWebhookResponseItemModel"
        }
      }
    },
    "v0.AppWebhookDeletedResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.AppWebhookResponseItemModel"
        }
      }
    },
    "v0.AppWebhookListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.AppWebhookResponseItemModel"
          }
        },
        "paging": {
          "description": "pagination",
          "allOf": [
            {
              "$ref": "#/definitions/v0.PagingResponseModel"
            }
          ]
        }
      }
    },
    "v0.AppWebhookResponseItemModel": {
      "type": "object",
      "properties": {
        "created_at": {
          "type": "string"
        },
        "events": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "headers": {
          "type": "object"
        },
        "registered_by_addon": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "updated_at": {
          "type": "string"
        },
        "url": {
          "type": "string"
        }
      }
    },
    "v0.AppWebhookResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.AppWebhookResponseItemModel"
        }
      }
    },
    "v0.AppWebhookUpdateParams": {
      "type": "object",
      "required": [
        "events",
        "url"
      ],
      "properties": {
        "events": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "headers": {
          "type": "object"
        },
        "url": {
          "type": "string"
        }
      }
    },
    "v0.AppleAPICredentialResponseItem": {
      "type": "object",
      "properties": {
        "created_at": {
          "type": "string"
        },
        "is_enterprise_account": {
          "type": "boolean"
        },
        "issuer_id": {
          "type": "string"
        },
        "key_id": {
          "type": "string"
        },
        "name": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "updated_at": {
          "type": "string"
        }
      }
    },
    "v0.AppleAPICredentialsListResponse": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.AppleAPICredentialResponseItem"
          }
        }
      }
    },
    "v0.ArchivedBuildArtifact": {
      "type": "object",
      "properties": {
        "artifact_meta": {
          "type": "object",
          "additionalProperties": true
        },
        "artifact_type": {
          "type": "string"
        },
        "created_at": {
          "type": "string"
        },
        "file_size_bytes": {
          "type": "integer"
        },
        "id": {
          "type": "string"
        },
        "is_public_page_enabled": {
          "type": "boolean"
        },
        "public_page_token": {
          "type": "string"
        },
        "title": {
          "type": "string"
        }
      }
    },
    "v0.ArchivedBuildListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.ArchivedBuildResponseItemModel"
          }
        },
        "paging": {
          "description": "pagination",
          "allOf": [
            {
              "$ref": "#/definitions/v0.PagingResponseModel"
            }
          ]
        }
      }
    },
    "v0.ArchivedBuildResponseItemModel": {
      "type": "object",
      "properties": {
        "abort_reason": {
          "type": "string"
        },
        "branch": {
          "type": "string"
        },
        "build_artifacts": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.ArchivedBuildArtifact"
          }
        },
        "build_number": {
          "type": "integer"
        },
        "commit_hash": {
          "type": "string"
        },
        "commit_message": {
          "type": "string"
        },
        "credit_cost": {
          "type": "integer"
        },
        "finished_at": {
          "type": "string"
        },
        "machine_type_id": {
          "type": "string"
        },
        "original_build_params": {
          "type": "object"
        },
        "pipeline_workflow_id": {
          "type": "string"
        },
        "pull_request_id": {
          "type": "integer"
        },
        "pull_request_target_branch": {
          "type": "string"
        },
        "pull_request_view_url": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "stack_identifier": {
          "type": "string"
        },
        "started_on_worker_at": {
          "type": "string"
        },
        "status": {
          "type": "integer"
        },
        "status_text": {
          "type": "string"
        },
        "tag": {
          "type": "string"
        },
        "triggered_by": {
          "type": "string"
        },
        "triggered_workflow": {
          "type": "string"
        }
      }
    },
    "v0.ArtifactDeleteResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.ArtifactResponseItemModel"
        }
      }
    },
    "v0.ArtifactListElementResponseModel": {
      "type": "object",
      "properties": {
        "artifact_meta": {
          "type": "object"
        },
        "artifact_type": {
          "type": "string"
        },
        "file_size_bytes": {
          "type": "integer"
        },
        "intermediate_file_info": {
          "type": "object"
        },
        "is_public_page_enabled": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "title": {
          "type": "string"
        }
      }
    },
    "v0.ArtifactListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.ArtifactListElementResponseModel"
          }
        },
        "paging": {
          "description": "pagination",
          "allOf": [
            {
              "$ref": "#/definitions/v0.PagingResponseModel"
            }
          ]
        }
      }
    },
    "v0.ArtifactResponseItemModel": {
      "type": "object",
      "properties": {
        "artifact_meta": {
          "type": "object"
        },
        "artifact_type": {
          "type": "string"
        },
        "expiring_download_url": {
          "type": "string"
        },
        "file_size_bytes": {
          "type": "integer"
        },
        "intermediate_file_info": {
          "type": "object"
        },
        "is_public_page_enabled": {
          "type": "boolean"
        },
        "public_install_page_url": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "title": {
          "type": "string"
        }
      }
    },
    "v0.ArtifactShowResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.ArtifactResponseItemModel"
        }
      }
    },
    "v0.ArtifactUpdateParams": {
      "type": "object",
      "required": [
        "is_public_page_enabled"
      ],
      "properties": {
        "is_public_page_enabled": {
          "type": "boolean"
        }
      }
    },
    "v0.BitriseYMLConfigGetResponse": {
      "type": "object",
      "properties": {
        "location": {
          "description": "Location of bitrise.yml file. Enums(bitrise.io, repository)",
          "allOf": [
            {
              "$ref": "#/definitions/website.BitriseYMLLocation"
            }
          ]
        }
      }
    },
    "v0.BitriseYMLConfigUpdateParams": {
      "type": "object",
      "properties": {
        "location": {
          "description": "Location of bitrise.yml file. Enums(bitrise.io, repository)",
          "allOf": [
            {
              "$ref": "#/definitions/website.BitriseYMLLocation"
            }
          ],
          "example": "repository"
        }
      }
    },
    "v0.BranchListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "v0.BuildAbortParams": {
      "type": "object",
      "required": [
        "abort_reason",
        "abort_with_success",
        "skip_git_status_report",
        "skip_notifications"
      ],
      "properties": {
        "abort_reason": {
          "type": "string"
        },
        "abort_with_success": {
          "type": "boolean"
        },
        "skip_git_status_report": {
          "type": "boolean"
        },
        "skip_notifications": {
          "type": "boolean"
        }
      }
    },
    "v0.BuildAbortResponseModel": {
      "type": "object",
      "properties": {
        "status": {
          "type": "string"
        }
      }
    },
    "v0.BuildCertificateContentModel": {
      "type": "object",
      "properties": {
        "expiry_date": {
          "description": "Read-only. This certificate's notAfter date in RFC 3339 / ISO 8601 (UTC). Computed server-side once the file is processed; null when it could not be extracted from the certificate.",
          "type": "string",
          "format": "date-time",
          "readOnly": true,
          "example": "2027-05-28T00:00:00Z"
        },
        "serial": {
          "description": "Read-only. X.509 serial number of this certificate, rendered as uppercase hexadecimal. Computed server-side once the file is processed; null when it could not be extracted from the certificate.",
          "type": "string",
          "readOnly": true,
          "example": "A1B2C3D4E5F60718"
        }
      }
    },
    "v0.BuildCertificateDownloadResponseItemModel": {
      "type": "object",
      "properties": {
        "certificate_password": {
          "type": "string"
        },
        "certificates": {
          "description": "Read-only. The signing certificates contained in the .p12 file. A single .p12 can bundle several independent certificates (for example a development and a distribution one), so this is always an array. The entries keep the order the .p12 itself stores them in (its ASN.1 sequence order) and are not re-sorted. Computed server-side once the file is processed; never null, but empty until then or when the extraction failed.",
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.BuildCertificateContentModel"
          },
          "readOnly": true
        },
        "download_url": {
          "type": "string"
        },
        "file_sha256": {
          "description": "Read-only. SHA-256 hash of the uploaded file bytes, rendered as lowercase hexadecimal. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        }
      }
    },
    "v0.BuildCertificateDownloadResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.BuildCertificateDownloadResponseItemModel"
        }
      }
    },
    "v0.BuildCertificateListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.BuildCertificateResponseItemModel"
          }
        },
        "paging": {
          "description": "pagination",
          "allOf": [
            {
              "$ref": "#/definitions/v0.PagingResponseModel"
            }
          ]
        }
      }
    },
    "v0.BuildCertificateResponseItemModel": {
      "type": "object",
      "properties": {
        "certificate_password": {
          "type": "string"
        },
        "certificates": {
          "description": "Read-only. The signing certificates contained in the .p12 file. A single .p12 can bundle several independent certificates (for example a development and a distribution one), so this is always an array. The entries keep the order the .p12 itself stores them in (its ASN.1 sequence order) and are not re-sorted. Computed server-side once the file is processed; never null, but empty until then or when the extraction failed.",
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.BuildCertificateContentModel"
          },
          "readOnly": true
        },
        "file_sha256": {
          "description": "Read-only. SHA-256 hash of the uploaded file bytes, rendered as lowercase hexadecimal. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        }
      }
    },
    "v0.BuildCertificateResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.BuildCertificateResponseItemModel"
        }
      }
    },
    "v0.BuildCertificateUpdateParams": {
      "type": "object",
      "properties": {
        "certificate_password": {
          "type": "string"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        }
      }
    },
    "v0.BuildCertificateUploadParams": {
      "type": "object",
      "required": [
        "upload_file_name",
        "upload_file_size"
      ],
      "properties": {
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        }
      }
    },
    "v0.BuildCertificateUploadResponseItemModel": {
      "type": "object",
      "properties": {
        "certificate_password": {
          "type": "string"
        },
        "certificates": {
          "description": "Read-only. The signing certificates contained in the .p12 file. A single .p12 can bundle several independent certificates (for example a development and a distribution one), so this is always an array. The entries keep the order the .p12 itself stores them in (its ASN.1 sequence order) and are not re-sorted. Computed server-side once the file is processed; never null, but empty until then or when the extraction failed.",
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.BuildCertificateContentModel"
          },
          "readOnly": true
        },
        "file_sha256": {
          "description": "Read-only. SHA-256 hash of the uploaded file bytes, rendered as lowercase hexadecimal. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        },
        "upload_url": {
          "type": "string"
        }
      }
    },
    "v0.BuildCertificateUploadResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.BuildCertificateUploadResponseItemModel"
        }
      }
    },
    "v0.BuildListAllResponseItemModel": {
      "type": "object",
      "properties": {
        "abort_reason": {
          "type": "string"
        },
        "branch": {
          "type": "string"
        },
        "build_number": {
          "type": "integer"
        },
        "commit_hash": {
          "type": "string"
        },
        "commit_message": {
          "type": "string"
        },
        "commit_view_url": {
          "type": "string"
        },
        "credit_cost": {
          "type": "integer"
        },
        "environment_prepare_finished_at": {
          "type": "string"
        },
        "finished_at": {
          "type": "string"
        },
        "is_on_hold": {
          "type": "boolean"
        },
        "is_processed": {
          "type": "boolean"
        },
        "machine_type_id": {
          "type": "string"
        },
        "original_build_params": {
          "type": "object"
        },
        "pull_request_id": {
          "type": "integer"
        },
        "pull_request_target_branch": {
          "type": "string"
        },
        "pull_request_view_url": {
          "type": "string"
        },
        "repository": {
          "$ref": "#/definitions/v0.AppResponseItemModel"
        },
        "slug": {
          "type": "string"
        },
        "stack_identifier": {
          "type": "string"
        },
        "started_on_worker_at": {
          "type": "string"
        },
        "status": {
          "type": "integer"
        },
        "status_text": {
          "type": "string"
        },
        "tag": {
          "type": "string"
        },
        "triggered_at": {
          "type": "string"
        },
        "triggered_by": {
          "type": "string"
        },
        "triggered_workflow": {
          "type": "string"
        },
        "utility": {
          "type": "boolean"
        }
      }
    },
    "v0.BuildListAllResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.BuildListAllResponseItemModel"
          }
        },
        "paging": {
          "description": "pagination",
          "allOf": [
            {
              "$ref": "#/definitions/v0.PagingResponseModel"
            }
          ]
        }
      }
    },
    "v0.BuildListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.BuildResponseItemModel"
          }
        },
        "paging": {
          "description": "pagination",
          "allOf": [
            {
              "$ref": "#/definitions/v0.PagingResponseModel"
            }
          ]
        }
      }
    },
    "v0.BuildParamsEnvironment": {
      "type": "object",
      "properties": {
        "is_expand": {
          "type": "boolean"
        },
        "key": {
          "type": "string"
        },
        "mapped_to": {
          "description": "Deprecated. Please use `key` instead.",
          "type": "string",
          "example": "Deprecated. Please use key instead"
        },
        "value": {
          "type": "string"
        }
      }
    },
    "v0.BuildRequestListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.BuildRequestResponseItemModel"
          }
        }
      }
    },
    "v0.BuildRequestResponseItemModel": {
      "type": "object",
      "properties": {
        "build_params": {
          "type": "object"
        },
        "created_at": {
          "type": "string"
        },
        "pull_request_url": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        }
      }
    },
    "v0.BuildRequestUpdateParams": {
      "type": "object",
      "required": [
        "is_approved"
      ],
      "properties": {
        "is_approved": {
          "type": "boolean"
        }
      }
    },
    "v0.BuildRequestUpdateResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.BuildRequestResponseItemModel"
        }
      }
    },
    "v0.BuildResponseItemModel": {
      "type": "object",
      "properties": {
        "abort_reason": {
          "type": "string"
        },
        "branch": {
          "type": "string"
        },
        "build_number": {
          "type": "integer"
        },
        "commit_hash": {
          "type": "string"
        },
        "commit_message": {
          "type": "string"
        },
        "commit_view_url": {
          "type": "string"
        },
        "credit_cost": {
          "type": "integer"
        },
        "environment_prepare_finished_at": {
          "type": "string"
        },
        "finished_at": {
          "type": "string"
        },
        "is_on_hold": {
          "type": "boolean"
        },
        "is_processed": {
          "type": "boolean"
        },
        "is_status_sent": {
          "type": "boolean"
        },
        "log_format": {
          "type": "string"
        },
        "machine_type_id": {
          "type": "string"
        },
        "original_build_params": {
          "type": "object"
        },
        "pipeline_workflow_id": {
          "type": "string"
        },
        "pull_request_id": {
          "type": "integer"
        },
        "pull_request_target_branch": {
          "type": "string"
        },
        "pull_request_view_url": {
          "type": "string"
        },
        "rebuildable": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "stack_identifier": {
          "type": "string"
        },
        "started_on_worker_at": {
          "type": "string"
        },
        "status": {
          "type": "integer"
        },
        "status_text": {
          "type": "string"
        },
        "tag": {
          "type": "string"
        },
        "triggered_at": {
          "type": "string"
        },
        "triggered_by": {
          "type": "string"
        },
        "triggered_workflow": {
          "type": "string"
        },
        "utility": {
          "type": "boolean"
        }
      }
    },
    "v0.BuildShowResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.BuildResponseItemModel"
        }
      }
    },
    "v0.BuildTriggerParams": {
      "type": "object",
      "properties": {
        "build_params": {
          "$ref": "#/definitions/v0.BuildTriggerParamsBuildParams"
        },
        "hook_info": {
          "$ref": "#/definitions/v0.BuildTriggerParamsHookInfo"
        }
      }
    },
    "v0.BuildTriggerParamsBuildParams": {
      "type": "object",
      "properties": {
        "base_repository_url": {
          "type": "string"
        },
        "branch": {
          "type": "string"
        },
        "branch_dest": {
          "type": "string"
        },
        "branch_dest_repo_owner": {
          "type": "string"
        },
        "branch_repo_owner": {
          "type": "string"
        },
        "build_request_slug": {
          "type": "string"
        },
        "commit_hash": {
          "type": "string"
        },
        "commit_message": {
          "type": "string"
        },
        "commit_paths": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.CommitPaths"
          }
        },
        "diff_url": {
          "type": "string"
        },
        "environments": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.BuildParamsEnvironment"
          }
        },
        "head_repository_url": {
          "type": "string"
        },
        "machine_type_id": {
          "description": "The machine type to run the build on. Overrides the app's default machine type.",
          "type": "string",
          "example": "g2-m1.4core"
        },
        "pipeline_id": {
          "type": "string"
        },
        "priority": {
          "type": "integer"
        },
        "pull_request_author": {
          "type": "string"
        },
        "pull_request_head_branch": {
          "type": "string"
        },
        "pull_request_id": {},
        "pull_request_merge_branch": {
          "type": "string"
        },
        "pull_request_repository_url": {
          "type": "string"
        },
        "pull_request_unverified_merge_branch": {
          "type": "string"
        },
        "secrets": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.Secret"
          }
        },
        "skip_git_status_report": {
          "type": "boolean"
        },
        "stack": {
          "description": "The stack to run the build on. Overrides the app's default stack.",
          "type": "string",
          "example": "osx-xcode-16.0.x"
        },
        "tag": {
          "type": "string"
        },
        "workflow_id": {
          "type": "string"
        }
      }
    },
    "v0.BuildTriggerParamsHookInfo": {
      "type": "object",
      "properties": {
        "type": {
          "description": "Should be \"bitrise\"",
          "type": "string",
          "example": "bitrise"
        }
      }
    },
    "v0.BuildTriggerRespItemModel": {
      "type": "object",
      "properties": {
        "build_number": {
          "type": "integer"
        },
        "build_slug": {
          "type": "string"
        },
        "build_url": {
          "type": "string"
        },
        "message": {
          "type": "string"
        },
        "status": {
          "type": "string"
        },
        "triggered_pipeline": {
          "type": "string"
        },
        "triggered_workflow": {
          "type": "string"
        }
      }
    },
    "v0.BuildTriggerRespModel": {
      "type": "object",
      "properties": {
        "build_number": {
          "description": "Deprecated",
          "type": "integer"
        },
        "build_slug": {
          "description": "Deprecated",
          "type": "string"
        },
        "build_url": {
          "description": "Deprecated",
          "type": "string"
        },
        "message": {
          "type": "string"
        },
        "results": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.BuildTriggerRespItemModel"
          }
        },
        "service": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "status": {
          "type": "string"
        },
        "triggered_workflow": {
          "description": "Deprecated",
          "type": "string"
        }
      }
    },
    "v0.BuildWorkflowListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "v0.CacheItemDownloadResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.CacheItemDownloadURLResponseModel"
        }
      }
    },
    "v0.CacheItemDownloadURLResponseModel": {
      "type": "object",
      "properties": {
        "download_url": {
          "type": "string"
        }
      }
    },
    "v0.CacheItemListResponseItemModel": {
      "type": "object",
      "properties": {
        "app_id": {
          "type": "string"
        },
        "archive_filename": {
          "type": "string"
        },
        "archive_size": {
          "type": "integer"
        },
        "cache_key": {
          "type": "string"
        },
        "created_at": {
          "type": "string"
        },
        "expires_at": {
          "type": "string"
        },
        "id": {
          "type": "string"
        },
        "last_used_at": {
          "type": "string"
        },
        "storage_provider": {
          "type": "string"
        }
      }
    },
    "v0.CacheItemListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.CacheItemListResponseItemModel"
          }
        },
        "paging": {
          "$ref": "#/definitions/v0.PagingResponseModel"
        }
      }
    },
    "v0.CommitPaths": {
      "type": "object",
      "properties": {
        "added": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "modified": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "removed": {
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "v0.OrganizationAppleAPICredentialResponseItem": {
      "type": "object",
      "properties": {
        "created_at": {
          "type": "string"
        },
        "is_enterprise_account": {
          "type": "boolean"
        },
        "issuer_id": {
          "type": "string"
        },
        "key_id": {
          "type": "string"
        },
        "name": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "updated_at": {
          "type": "string"
        }
      }
    },
    "v0.OrganizationAppleAPICredentialsListResponse": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.OrganizationAppleAPICredentialResponseItem"
          }
        }
      }
    },
    "v0.OrganizationAppleAPICredetialCreateParams": {
      "type": "object",
      "properties": {
        "is_enterprise_account": {
          "type": "boolean"
        },
        "issuer_id": {
          "type": "string"
        },
        "key_id": {
          "type": "string"
        },
        "name": {
          "type": "string"
        },
        "private_key": {
          "type": "string"
        }
      }
    },
    "v0.OrganizationAppleAPICredetialCreateResponse": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.OrganizationAppleAPICredetialCreateResponseItem"
        }
      }
    },
    "v0.OrganizationAppleAPICredetialCreateResponseItem": {
      "type": "object",
      "properties": {
        "created_at": {
          "type": "string"
        },
        "is_enterprise_account": {
          "type": "boolean"
        },
        "issuer_id": {
          "type": "string"
        },
        "key_id": {
          "type": "string"
        },
        "name": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        }
      }
    },
    "v0.OrganizationDataModel": {
      "type": "object",
      "properties": {
        "avatar_icon_url": {
          "type": "string"
        },
        "concurrency_count": {
          "type": "integer"
        },
        "name": {
          "type": "string"
        },
        "owners": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.OrganizationOwner"
          }
        },
        "slug": {
          "type": "string"
        }
      }
    },
    "v0.OrganizationGoogleServiceCredentialResponseItem": {
      "type": "object",
      "properties": {
        "created_at": {
          "type": "string"
        },
        "is_enterprise_account": {
          "type": "boolean"
        },
        "issuer_id": {
          "type": "string"
        },
        "key_id": {
          "type": "string"
        },
        "name": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "updated_at": {
          "type": "string"
        }
      }
    },
    "v0.OrganizationGoogleServiceCredentialsListResponse": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.OrganizationGoogleServiceCredentialResponseItem"
          }
        }
      }
    },
    "v0.OrganizationGoogleServiceCredetialCreateParams": {
      "type": "object",
      "properties": {
        "credentials": {
          "type": "string"
        },
        "name": {
          "type": "string"
        }
      }
    },
    "v0.OrganizationGoogleServiceCredetialCreateResponse": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.OrganizationGoogleServiceCredetialCreateResponseItem"
        }
      }
    },
    "v0.OrganizationGoogleServiceCredetialCreateResponseItem": {
      "type": "object",
      "properties": {
        "created_at": {
          "type": "string"
        },
        "id": {
          "type": "string"
        },
        "name": {
          "type": "string"
        }
      }
    },
    "v0.OrganizationListRespModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.OrganizationDataModel"
          }
        }
      }
    },
    "v0.OrganizationOwner": {
      "type": "object",
      "properties": {
        "email": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "username": {
          "type": "string"
        }
      }
    },
    "v0.OrganizationRespModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.OrganizationDataModel"
        }
      }
    },
    "v0.OrganizationUpdateMachineTypeParams": {
      "type": "object",
      "properties": {
        "from_machine": {
          "description": "Machine type to migrate from",
          "type": "string"
        },
        "to_machine": {
          "description": "Machine type to migrate to",
          "type": "string"
        }
      }
    },
    "v0.OrganizationUpdateMachineTypeResponse": {
      "type": "object",
      "properties": {
        "errors": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "app": {
                "description": "The apps which had an error's identifiers in the following format \"#{app.title} (#{app.slug})\"",
                "type": "string"
              },
              "error": {
                "type": "string"
              }
            }
          }
        },
        "message": {
          "description": "The result of the migration",
          "type": "string"
        },
        "migrated_apps": {
          "description": "The migrated apps' identifiers in the following format \"#{app.title} (#{app.slug})\"",
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "v0.OwnerAccountResponseModel": {
      "type": "object",
      "properties": {
        "account_type": {
          "type": "string"
        },
        "name": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        }
      }
    },
    "v0.OwnerAddOnResponseItemModel": {
      "type": "object",
      "properties": {
        "apps": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.AddOnAppResponseItemModel"
          }
        },
        "documentation_url": {
          "type": "string"
        },
        "has_ui": {
          "type": "boolean"
        },
        "icon": {
          "type": "string"
        },
        "id": {
          "type": "string"
        },
        "is_beta": {
          "type": "boolean"
        },
        "summary": {
          "type": "string"
        },
        "title": {
          "type": "string"
        }
      }
    },
    "v0.OwnerAddOnsListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.OwnerAddOnResponseItemModel"
          }
        }
      }
    },
    "v0.PagingResponseModel": {
      "type": "object",
      "properties": {
        "next": {
          "description": "Next is the \"anchor\" for pagination. This value should be passed to the same endpoint\nto get the next page. Empty/not included if there's no \"next\" page.\nStop paging when there's no \"Next\" item in the response!",
          "type": "string"
        },
        "page_item_limit": {
          "description": "PageItemLimit - per-page item count. A given page might include\nless items if there's not enough items. This value is the \"max item count per page\".",
          "type": "integer"
        },
        "total_item_count": {
          "description": "TotalItemCount - total item count, through \"all pages\"",
          "type": "integer"
        }
      }
    },
    "v0.PipelineAbortParams": {
      "type": "object",
      "required": [
        "abort_reason",
        "abort_with_success",
        "skip_notifications"
      ],
      "properties": {
        "abort_reason": {
          "type": "string"
        },
        "abort_with_success": {
          "type": "boolean"
        },
        "skip_notifications": {
          "type": "boolean"
        }
      }
    },
    "v0.PipelineListAllResponseItemModel": {
      "type": "object",
      "properties": {
        "branch": {
          "type": "string"
        },
        "build_number": {
          "type": "integer"
        },
        "commit_hash": {
          "type": "string"
        },
        "commit_message": {
          "type": "string"
        },
        "credit_cost": {
          "type": "integer"
        },
        "finished_at": {
          "type": "string"
        },
        "is_on_hold": {
          "type": "boolean"
        },
        "is_pipeline": {
          "type": "boolean"
        },
        "is_processed": {
          "type": "boolean"
        },
        "pull_request_id": {
          "type": "integer"
        },
        "pull_request_target_branch": {
          "type": "string"
        },
        "repository": {
          "$ref": "#/definitions/v0.AppResponseItemModel"
        },
        "slug": {
          "type": "string"
        },
        "started_at": {
          "type": "string"
        },
        "status": {
          "type": "integer"
        },
        "tag": {
          "type": "string"
        },
        "trigger_params": {
          "$ref": "#/definitions/v0.PipelineListAllTriggerParams"
        },
        "triggered_at": {
          "type": "string"
        },
        "triggered_by": {
          "type": "string"
        },
        "triggered_workflow": {
          "type": "string"
        },
        "utility": {
          "type": "boolean"
        }
      }
    },
    "v0.PipelineListAllResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.PipelineListAllResponseItemModel"
          }
        },
        "paging": {
          "$ref": "#/definitions/v0.PagingResponseModel"
        }
      }
    },
    "v0.PipelineListAllTriggerParams": {
      "type": "object",
      "properties": {
        "priority": {
          "type": "integer"
        }
      }
    },
    "v0.PipelineListResponseItemModel": {
      "type": "object",
      "properties": {
        "artifacts": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/pipelineabledomain.ArtifactMeta"
          }
        },
        "branch": {
          "type": "string"
        },
        "build_number": {
          "type": "integer"
        },
        "build_tool_invocations": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/pipelineabledomain.BuildToolInvocation"
          }
        },
        "commit_hash": {
          "type": "string"
        },
        "commit_message": {
          "type": "string"
        },
        "credit_cost": {
          "type": "integer"
        },
        "finished_at": {
          "type": "string"
        },
        "is_on_hold": {
          "type": "boolean"
        },
        "is_pipeline": {
          "type": "boolean"
        },
        "is_processed": {
          "type": "boolean"
        },
        "local_config": {
          "$ref": "#/definitions/pipelineabledomain.LocalConfig"
        },
        "pull_request_id": {
          "type": "integer"
        },
        "pull_request_target_branch": {
          "type": "string"
        },
        "rebuildable": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "started_at": {
          "type": "string"
        },
        "status": {
          "type": "integer"
        },
        "tag": {
          "type": "string"
        },
        "trigger_params": {
          "$ref": "#/definitions/pipelineabledomain.TriggerParams"
        },
        "triggered_at": {
          "type": "string"
        },
        "triggered_by": {
          "type": "string"
        },
        "triggered_workflow": {
          "type": "string"
        },
        "utility": {
          "type": "boolean"
        }
      }
    },
    "v0.PipelineListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.PipelineListResponseItemModel"
          }
        },
        "paging": {
          "description": "pagination",
          "allOf": [
            {
              "$ref": "#/definitions/v0.PagingResponseModel"
            }
          ]
        }
      }
    },
    "v0.PipelineRebuildParams": {
      "type": "object",
      "properties": {
        "partial": {
          "type": "boolean"
        },
        "triggered_by": {
          "type": "string"
        }
      }
    },
    "v0.PipelineShowAppResponseModel": {
      "type": "object",
      "properties": {
        "slug": {
          "type": "string"
        }
      }
    },
    "v0.PipelineShowAttemptResponseModel": {
      "type": "object",
      "properties": {
        "id": {
          "type": "string"
        },
        "number_in_pipeline_build_scope": {
          "type": "integer"
        },
        "status": {
          "type": "string"
        },
        "triggered_at": {
          "type": "string"
        }
      }
    },
    "v0.PipelineShowEnvironmentsResponseModel": {
      "type": "object",
      "properties": {
        "is_expand": {
          "type": "boolean"
        },
        "key": {
          "type": "string"
        },
        "value": {}
      }
    },
    "v0.PipelineShowResponseModel": {
      "type": "object",
      "properties": {
        "abort_reason": {
          "type": "string"
        },
        "app": {
          "$ref": "#/definitions/v0.PipelineShowAppResponseModel"
        },
        "attempts": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.PipelineShowAttemptResponseModel"
          }
        },
        "credit_cost": {},
        "current_attempt_id": {
          "type": "string"
        },
        "finished_at": {
          "type": "string"
        },
        "id": {
          "type": "string"
        },
        "name": {
          "type": "string"
        },
        "number_in_app_scope": {
          "type": "integer"
        },
        "put_on_hold_at": {},
        "rebuildable": {
          "type": "boolean"
        },
        "stages": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.PipelineShowStageResponseModel"
          }
        },
        "started_at": {
          "type": "string"
        },
        "status": {
          "type": "string",
          "enum": [
            "aborted",
            "failed",
            "initializing",
            "on_hold",
            "running",
            "succeeded",
            "succeeded_with_abort"
          ]
        },
        "trigger_params": {
          "$ref": "#/definitions/v0.PipelineShowTriggerParamsResponseModel"
        },
        "triggered_at": {
          "type": "string"
        },
        "triggered_by": {
          "type": "string"
        },
        "type": {
          "type": "string"
        },
        "workflows": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.PipelineShowWorkflowResponseModel"
          }
        }
      }
    },
    "v0.PipelineShowStageResponseModel": {
      "type": "object",
      "properties": {
        "id": {
          "type": "string"
        },
        "name": {
          "type": "string"
        },
        "workflows": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.PipelineShowWorkflowResponseModel"
          }
        }
      }
    },
    "v0.PipelineShowTriggerParamsResponseModel": {
      "type": "object",
      "properties": {
        "branch": {
          "type": "string"
        },
        "branch_dest": {
          "type": "string"
        },
        "branch_dest_repo_owner": {
          "type": "string"
        },
        "branch_repo_owner": {
          "type": "string"
        },
        "commit_hash": {
          "type": "string"
        },
        "commit_message": {
          "type": "string"
        },
        "commit_messages": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "commit_paths": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.CommitPaths"
          }
        },
        "environments": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.PipelineShowEnvironmentsResponseModel"
          }
        },
        "pull_request_author": {
          "type": "string"
        },
        "pull_request_head_branch": {
          "type": "string"
        },
        "pull_request_id": {
          "type": "string"
        },
        "pull_request_merge_branch": {
          "type": "string"
        },
        "pull_request_repository_url": {
          "type": "string"
        },
        "pull_request_unverified_merge_branch": {
          "type": "string"
        },
        "tag": {
          "type": "string"
        }
      }
    },
    "v0.PipelineShowWorkflowResponseModel": {
      "type": "object",
      "properties": {
        "credit_cost": {},
        "depends_on": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "external_id": {
          "type": "string"
        },
        "finished_at": {
          "type": "string"
        },
        "id": {
          "type": "string"
        },
        "is_generator": {
          "type": "boolean"
        },
        "name": {
          "type": "string"
        },
        "startFailureReason": {
          "type": "string"
        },
        "started_at": {
          "type": "string"
        },
        "status": {
          "type": "string"
        }
      }
    },
    "v0.ProjectFileStorageDocumentUpdateParams": {
      "type": "object",
      "properties": {
        "exposed_meta_datastore": {
          "type": "object"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "user_env_key": {
          "type": "string"
        }
      }
    },
    "v0.ProjectFileStorageDownloadResponseItemModel": {
      "type": "object",
      "properties": {
        "download_url": {
          "type": "string"
        },
        "exposed_meta_datastore": {
          "type": "object"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        },
        "user_env_key": {
          "type": "string"
        }
      }
    },
    "v0.ProjectFileStorageDownloadResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.ProjectFileStorageDownloadResponseItemModel"
        }
      }
    },
    "v0.ProjectFileStorageListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.ProjectFileStorageResponseItemModel"
          }
        },
        "paging": {
          "description": "pagination",
          "allOf": [
            {
              "$ref": "#/definitions/v0.PagingResponseModel"
            }
          ]
        }
      }
    },
    "v0.ProjectFileStorageResponseItemModel": {
      "type": "object",
      "properties": {
        "exposed_meta_datastore": {
          "type": "object"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        },
        "user_env_key": {
          "type": "string"
        }
      }
    },
    "v0.ProjectFileStorageResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.ProjectFileStorageResponseItemModel"
        }
      }
    },
    "v0.ProjectFileStorageUploadParams": {
      "type": "object",
      "required": [
        "upload_file_name",
        "upload_file_size",
        "user_env_key"
      ],
      "properties": {
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        },
        "user_env_key": {
          "type": "string"
        }
      }
    },
    "v0.ProjectFileStorageUploadResponseItemModel": {
      "type": "object",
      "properties": {
        "exposed_meta_datastore": {
          "type": "object"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        },
        "upload_url": {
          "type": "string"
        },
        "user_env_key": {
          "type": "string"
        }
      }
    },
    "v0.ProjectFileStorageUploadResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.ProjectFileStorageUploadResponseItemModel"
        }
      }
    },
    "v0.ProvProfileDocumentUpdateParams": {
      "type": "object",
      "properties": {
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        }
      }
    },
    "v0.ProvisionProfileDownloadResponseItemModel": {
      "type": "object",
      "properties": {
        "download_url": {
          "type": "string"
        },
        "expiry_date": {
          "description": "Read-only. The profile's expiration date in RFC 3339 / ISO 8601 (UTC). Computed server-side once the file is processed; null until then.",
          "type": "string",
          "format": "date-time",
          "readOnly": true,
          "example": "2027-05-28T00:00:00Z"
        },
        "file_sha256": {
          "description": "Read-only. SHA-256 hash of the uploaded file bytes, rendered as lowercase hexadecimal. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        },
        "uuid": {
          "description": "Read-only. UUID of the provisioning profile. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "f8f7817c-6671-41ce-aacc-8b8363ccd225"
        }
      }
    },
    "v0.ProvisionProfileDownloadResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.ProvisionProfileDownloadResponseItemModel"
        }
      }
    },
    "v0.ProvisionProfileListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.ProvisionProfileResponseItemModel"
          }
        },
        "paging": {
          "description": "pagination",
          "allOf": [
            {
              "$ref": "#/definitions/v0.PagingResponseModel"
            }
          ]
        }
      }
    },
    "v0.ProvisionProfileResponseItemModel": {
      "type": "object",
      "properties": {
        "expiry_date": {
          "description": "Read-only. The profile's expiration date in RFC 3339 / ISO 8601 (UTC). Computed server-side once the file is processed; null until then.",
          "type": "string",
          "format": "date-time",
          "readOnly": true,
          "example": "2027-05-28T00:00:00Z"
        },
        "file_sha256": {
          "description": "Read-only. SHA-256 hash of the uploaded file bytes, rendered as lowercase hexadecimal. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        },
        "uuid": {
          "description": "Read-only. UUID of the provisioning profile. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "f8f7817c-6671-41ce-aacc-8b8363ccd225"
        }
      }
    },
    "v0.ProvisionProfileResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.ProvisionProfileResponseItemModel"
        }
      }
    },
    "v0.ProvisionProfileUploadParams": {
      "type": "object",
      "required": [
        "upload_file_name",
        "upload_file_size"
      ],
      "properties": {
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        }
      }
    },
    "v0.ProvisionProfileUploadResponseItemModel": {
      "type": "object",
      "properties": {
        "expiry_date": {
          "description": "Read-only. The profile's expiration date in RFC 3339 / ISO 8601 (UTC). Computed server-side once the file is processed; null until then.",
          "type": "string",
          "format": "date-time",
          "readOnly": true,
          "example": "2027-05-28T00:00:00Z"
        },
        "file_sha256": {
          "description": "Read-only. SHA-256 hash of the uploaded file bytes, rendered as lowercase hexadecimal. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        },
        "is_expose": {
          "type": "boolean"
        },
        "is_protected": {
          "type": "boolean"
        },
        "processed": {
          "type": "boolean"
        },
        "slug": {
          "type": "string"
        },
        "upload_file_name": {
          "type": "string"
        },
        "upload_file_size": {
          "type": "integer"
        },
        "upload_url": {
          "type": "string"
        },
        "uuid": {
          "description": "Read-only. UUID of the provisioning profile. Computed server-side once the file is processed; null until then.",
          "type": "string",
          "readOnly": true,
          "example": "f8f7817c-6671-41ce-aacc-8b8363ccd225"
        }
      }
    },
    "v0.ProvisionProfileUploadResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.ProvisionProfileUploadResponseItemModel"
        }
      }
    },
    "v0.SSHKeyRespModel": {
      "type": "object",
      "properties": {
        "status": {
          "type": "string"
        }
      }
    },
    "v0.SSHKeyUploadParams": {
      "type": "object",
      "required": [
        "auth_ssh_private_key",
        "auth_ssh_public_key"
      ],
      "properties": {
        "auth_ssh_private_key": {
          "description": "The private part of the SSH key you would like to use",
          "type": "string"
        },
        "auth_ssh_public_key": {
          "description": "The public part of the SSH key you would like to use",
          "type": "string"
        },
        "is_register_key_into_provider_service": {
          "description": "If it's set to true, the provided SSH key will be registered at the provider of the application",
          "type": "boolean"
        }
      }
    },
    "v0.Secret": {
      "type": "object",
      "properties": {
        "is_expand": {
          "type": "boolean"
        },
        "key": {
          "type": "string"
        },
        "value": {
          "type": "string"
        }
      }
    },
    "v0.TestDeviceListResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/v0.TestDeviceResponseItemModel"
          }
        }
      }
    },
    "v0.TestDeviceResponseItemModel": {
      "type": "object",
      "properties": {
        "device_id": {
          "type": "string"
        },
        "device_type": {
          "type": "string"
        },
        "owner": {
          "type": "string"
        }
      }
    },
    "v0.UserProfileDataModel": {
      "type": "object",
      "properties": {
        "avatar_url": {
          "type": "string"
        },
        "created_at": {
          "type": "string"
        },
        "data_id": {
          "type": "integer"
        },
        "email": {
          "type": "string"
        },
        "has_used_organization_trial": {
          "type": "boolean"
        },
        "payment_processor": {
          "type": "string"
        },
        "slug": {
          "type": "string"
        },
        "unconfirmed_email": {
          "type": "string"
        },
        "username": {
          "type": "string"
        }
      }
    },
    "v0.UserProfileRespModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.UserProfileDataModel"
        }
      }
    },
    "v0.WebhookDeliveryItemResponseModel": {
      "type": "object",
      "properties": {
        "created_at": {
          "type": "string"
        },
        "request_headers": {
          "type": "string"
        },
        "request_payload": {
          "type": "string"
        },
        "request_url": {
          "type": "string"
        },
        "response_body": {
          "type": "string"
        },
        "response_headers": {
          "type": "string"
        },
        "response_http_status": {
          "type": "integer"
        },
        "response_seconds": {
          "type": "integer"
        },
        "slug": {
          "type": "string"
        },
        "updated_at": {
          "type": "string"
        }
      }
    },
    "v0.WebhookDeliveryItemShowResponseModel": {
      "type": "object",
      "properties": {
        "data": {
          "$ref": "#/definitions/v0.WebhookDeliveryItemResponseModel"
        }
      }
    },
    "v0.WebhookRespModel": {
      "type": "object",
      "properties": {
        "status": {
          "type": "string"
        }
      }
    },
    "website.BitriseYMLLocation": {
      "type": "string",
      "enum": [
        "bitrise.io",
        "repository"
      ],
      "x-enum-varnames": [
        "LocationBitriseIo",
        "LocationRepository"
      ]
    }
  },
  "securityDefinitions": {
    "AddonAuthToken": {
      "type": "apiKey",
      "name": "Bitrise-Addon-Auth-Token",
      "in": "header"
    },
    "PersonalAccessToken": {
      "type": "apiKey",
      "name": "Authorization",
      "in": "header"
    }
  }
}